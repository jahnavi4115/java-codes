

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletConfigDemo
 */
public class ServletConfigDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	//public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		//System.out.println(config.getServletName());
		//System.out.println(config.getServletContext());
	//}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
        ServletConfig config=getServletConfig();	
        //System.out.println(config.getServletName());
		//System.out.println(config.getServletContext());
		System.out.println(config.getInitParameter("Company"));
		System.out.println(config.getInitParameter("Location"));
		 ServletContext application=config.getServletContext();
	     System.out.println(application.getInitParameter("District"));
	}
}
