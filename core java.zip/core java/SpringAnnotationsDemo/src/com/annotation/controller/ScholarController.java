package com.annotation.controller;



import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.annotation.model.Scholar;



public class ScholarController {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scholar scholar=(Scholar) applicationContext.getBean("scholar");
		System.out.println(scholar.getSapId()+"  "+scholar.getName()+"  "+scholar.getStipend());
		System.out.println(scholar.getAddress().getDoorNo()+" "+scholar.getAddress().getStreet()+" "+scholar.getAddress().getState()+" "+scholar.getAddress().getPincode());
	}
}