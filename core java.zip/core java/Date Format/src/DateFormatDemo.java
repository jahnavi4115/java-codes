import java.text.ParseException;
import java.text.SimpleDateFormat;

public class DateFormatDemo {
   public static void main(String[] args) {
	String d="14-05-2001";
	try
	{
		SimpleDateFormat sdf=new SimpleDateFormat("dd-mm-yyyy");
		java.util.Date da=sdf.parse(d);
        java.sql.Date sd=new java.sql.Date(da.getTime());
		System.out.println(da+"\n"+sd);
	}
	catch(ParseException p)
	{
		System.out.println(p);
	}
	
}
}
