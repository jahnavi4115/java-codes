package revision;

public class Citizen implements Calculator {
    public void add()
    {
    	System.out.println("add");
    }
    public void sub()
    {
    	System.out.println("sub");
    }
    public void mul()
    {
    	System.out.println("mul");
    }
    public void div()
    {
    	System.out.println("div");
    }
}
