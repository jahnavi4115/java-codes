package revision;

public class Hiii {
	
		class MyException extends Exception{}
		public void myMethod() throws Exception{
			throw new MyException();
		}
}
