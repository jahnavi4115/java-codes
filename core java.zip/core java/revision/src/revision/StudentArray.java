package revision;

import java.util.Scanner;

public class StudentArray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int flag=0;
		System.out.println("Enter size : ");
		int size=Integer.parseInt(sc.nextLine());
		while(size<0)
		{
			System.out.println("Please enter valid size : ");
			size=Integer.parseInt(sc.nextLine());
		}
		Student s[]=new Student[size];
		for(int i=0;i<s.length;i++)
		{
			System.out.println("Enter details : ");
			s[i]=new Student(Integer.parseInt(sc.nextLine()),sc.nextLine(),Integer.parseInt(sc.nextLine()));
		}
		for(Student st:s)
		{
			System.out.println(st);
		}
		System.out.println("Enter Id to display the data : ");
		int id=Integer.parseInt(sc.nextLine());
		for(Student st:s)
		{
			if(st.getId()==id)
			{
				flag=1;
				System.out.print(st);
			}
		}
		if(flag==0)
		    System.out.println("Invalid Id");
		sc.close();
	}
}
