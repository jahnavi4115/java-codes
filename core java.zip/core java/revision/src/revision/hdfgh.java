package revision;

public class hdfgh{

	public static void main(String[] args) throws Exception{
	System.out.println(Math.floor(2.9999));
	  
	}

}
