package revision;

public interface Calculator {
     void add();
     void sub();
     void mul();
     void div();
}
