package revision;

import java.util.Scanner;

public class CombiningArray {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of first array : ");
		int size1=sc.nextInt();
		while(size1<0)
		{
			System.out.println("Please enter valid size : ");
			size1=sc.nextInt();
		}
		System.out.println("Enter size of second array : ");
		int size2=sc.nextInt();
		while(size2<0)
		{
			System.out.println("Please enter valid size : ");
			size2=sc.nextInt();
		}
		int arr1[]=new int[size1];
		System.out.println("Enter "+size1+" elements : ");
		for(int i=0;i<size1;i++)
			arr1[i]=sc.nextInt();
		int arr2[]=new int[size2];
		System.out.println("Enter "+size2+" elements : ");
		for(int i=0;i<size2;i++)
			arr2[i]=sc.nextInt();
		int arr[]=new int[size1+size2];
		for(int i=0,j=0;i<arr.length;i++)
		{
			if(i<size1)
				arr[i]=arr1[i];
			else
				arr[i]=arr2[j++];
		}
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]+" ");
		sc.close();
	}
}
