package revision;

import java.util.LinkedHashSet;
import java.util.Set;

class Invoice{
	public static String formatId(String oldId)
	{
		return oldId+"_Invoice";
	}
}
class SalesInvoice extends Invoice{
	public static String formatId(String oldId){
		return oldId+"_SalesInvoice";
	}
}
public class Hi {
    public static void main(String[] args) {
	    Invoice invoice=new Invoice();
	    System.out.println(invoice.formatId("1234"));
	}
}
