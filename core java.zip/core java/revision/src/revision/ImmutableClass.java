package revision;

public class ImmutableClass {
	final int x;
	ImmutableClass(int x)
	{
		this.x=x;
	}
	int getX()
	{
		return x;
	}
}