package revision;

import java.util.Scanner;

public class Series {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of terms : ");
        int n=sc.nextInt();
        sc.close();
        System.out.println("Series till "+n+" terms : " );
        for(int i=1;i<=n;i++)
        {
        	System.out.print((i*i+1)+" ");
        }
    }
}
