package revision;

public class InterfaceExample {
    public static void main(String[] args) {
		Calculator c=new Citizen();
		c.add();
		c.sub();
		c.mul();
		c.div();
	}
}
