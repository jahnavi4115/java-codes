package revision;

import java.util.Scanner;

public class IncomeTax {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Gross Salary : ");
        int grossSalary=sc.nextInt();
        sc.close();
        if(grossSalary<0)  //If Gross Salary is negative then exception will be thrown
        {
        	try 
        	{
				throw new Exception("Gross salary can't be negative");
			} 
        	catch (Exception e)
        	{
				System.out.println(e.getMessage());
			}
        }
        else if(grossSalary<=250000)  //If gross salary is between 0 and 250000 then this block will be executed
        {
        	System.out.println("No tax");
        }
        else if(grossSalary<=500000)   //If gross salary is between 250000 and 500000 then this block will be executed
        {
        	System.out.println("Tax = "+(grossSalary-250000)*0.05f);
        }
        else if(grossSalary<=1000000)  //If gross salary is between 500000 and 1000000 then this block will be executed
        {
        	System.out.println("Tax = "+((grossSalary-500000)*0.2f+(0.05f*250000)));
        }
        else  //If gross salary is greater than 1000000 then this block will be executed
        {
        	System.out.println("Tax = "+((grossSalary-1000000)*0.3+(0.05f*250000)+(0.2f*500000)));
        }
	}
}
