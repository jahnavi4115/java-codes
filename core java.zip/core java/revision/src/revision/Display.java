package revision;

public class Display
{
	public static void main(String[] args) {
		ImmutableClass i=new ImmutableClass(123);
		System.out.println(i.getX());
	}
}
