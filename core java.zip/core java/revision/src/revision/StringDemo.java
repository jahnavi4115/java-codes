package revision;

public class StringDemo {
   public static void main(String[] args) {
	   String s="HCL";
	   s=s.concat("technologies");
	 System.out.println(s);
   }
}
