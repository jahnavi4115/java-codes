package revision;

public class Count {
  public static void main(String[] args) {
	String s="Hello! how are u, are u fine?1234";
	char c[]=s.toCharArray();
	int digit=0,upper=0,lower=0,space=0,special=0;
	for(char ch : c)
	{
		if(Character.isDigit(ch))
			digit++;
		else if(Character.isUpperCase(ch))
		    upper++;
		else if(Character.isLowerCase(ch))
			lower++;
		else if(Character.isSpace(ch))
		    space++;
		else
			special++;
	}
	System.out.println("Count of digit :"+digit);
	System.out.println("Count of Uppercase alphabets :"+upper);
	System.out.println("Count of Lowercase alphabets :"+lower);
	System.out.println("Count of spaces :"+space);
	System.out.println("Count of special characters :"+special);
  }
}
