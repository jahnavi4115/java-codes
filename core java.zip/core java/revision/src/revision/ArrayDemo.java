package revision;

import java.util.Scanner;

public class ArrayDemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int sum=0,even=0,odd=0,palindrome=0;
		System.out.println("Enter size : ");
		int size=sc.nextInt();
		if(size<0)
		{
			System.out.println("Invalid Size");
			System.exit(0);
		}
		else
		{
		    int arr[]=new int[size];
		    for(int i=0;i<size;i++)
		    {
		    	System.out.println("Enter element : ");
		    	arr[i]=sc.nextInt();
		    	sum+=arr[i];
		    	if(arr[i]%2==0)
		    		even++;
		    	else
		    		odd++;
		    }
		    System.out.println("Sum : "+sum);
		    System.out.print("\nEven count : "+even);
		    System.out.print("\nOdd count : "+odd);
		    System.out.print("\nPalindromes : ");
		    for(int i=0;i<size;i++)
		    {
		    	StringBuffer sb=new StringBuffer(arr[i]+"");
		    	if(sb.equals(sb.reverse().toString()))
		    	{
		    		System.out.print(arr[i]+" ");
		    		palindrome++;
		    	}
		    }
		    System.out.print("\nPalindromes count : "+palindrome);
		}
		sc.close();
	}
}
