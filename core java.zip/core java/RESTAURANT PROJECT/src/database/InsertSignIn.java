package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import jdbcconnection.DbFactory;

public class InsertSignIn {
	public static void main(String[] args) {
        Connection con=DbFactory.getConnection();
        try{
            PreparedStatement ps=DbFactory.getConnection().prepareStatement("insert into SignIn values(?,?)");
            Scanner sc=new Scanner(System.in);
		    String username=sc.nextLine();
		    String password=sc.nextLine();
		    sc.close();
		    ps.setString(1,username);
		    ps.setString(2,password);
        }
        catch(SQLException s)
        {
        	System.out.println(s);
        }
}
}
