package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import jdbcconnection.DbFactory;

public class CheckCredentials {
    public static void main(String[] args) {
        Connection con=DbFactory.getConnection();
        try{
            PreparedStatement ps=DbFactory.getConnection().prepareStatement("select * from SignIn where username=? and password=?");
            Scanner sc=new Scanner(System.in);
            System.out.println("Enter username : ");
            String username=sc.nextLine();
            System.out.print("Enter password : ");
            String password=sc.nextLine();
            sc.close();
            ps.setString(1,username);
            ps.setString(2,password);
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
                System.out.println("Credentials exists");
                con.commit();
                DbFactory.closeConnection();
            }
            else
                System.out.println("No such credentails");
        }
        catch(SQLException s)    
        {
            System.out.println(s);
        }
    }
}