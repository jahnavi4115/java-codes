package project;

import java.util.Scanner;

public class Restaurant {
  public static void main(String[] args) {
	  System.out.println("WELCOME");
	Scanner sc=new Scanner(System.in);
	
}
}
