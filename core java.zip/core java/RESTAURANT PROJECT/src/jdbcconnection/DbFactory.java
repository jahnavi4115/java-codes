package jdbcconnection;

 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

 

public class DbFactory {
    static Connection con;
    static public Connection getConnection(){
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
            if(con!=null)
            {
                con.setAutoCommit(false);
            }
        }
        catch(SQLException s)
        {
            System.out.println(s);
        }
        catch(ClassNotFoundException c)
        {
            System.out.println(c);
        }
        return con;
    }
    static public void closeConnection()
    {
        if(con!=null)
        {
            try{
                con.close();
            }
            catch(SQLException s)
            {
                System.out.println(s);
            }
        }
    }
}