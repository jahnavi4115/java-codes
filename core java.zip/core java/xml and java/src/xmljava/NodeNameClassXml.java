package xmljava;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class NodeNameClassXml {
  public static void main(String[] args) {
	try{
		String xmlFile="C:\\Jahnavi\\HCL.XML";
		
		DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
		DocumentBuilder builder=factory.newDocumentBuilder();
		Document doc=builder.parse(xmlFile);
		NodeList list=doc.getElementsByTagName("*");
		System.out.println("XML Elements : ");
		for(int i=0;i<list.getLength();i++)
		{
			Element element=(Element)list.item(i);
			System.out.println(element.getNodeName());
		}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
