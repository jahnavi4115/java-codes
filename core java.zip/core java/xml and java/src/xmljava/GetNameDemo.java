package xmljava;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;

public class GetNameDemo {
	public static void main(String[] args) {
		try{
			String xmlFile="C:\\Jahnavi\\HCL.xml";
			
			File file=new File(xmlFile);
			if(file.exists())
			{
				DocumentBuilderFactory factory=DocumentBuilderFactory.newInstance();
				DocumentBuilder builder=factory.newDocumentBuilder();
				Document doc=builder.parse(xmlFile);
				Transformer tFormer=TransformerFactory.newInstance().newTransformer();
				tFormer.setOutputProperty(OutputKeys.METHOD,"text");
				Source source=new DOMSource(doc);
				Result result=new StreamResult(System.out);
				tFormer.transform(source, result);
			}
			else
			{
				System.out.println("File not found!");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
