package Stock;

import java.util.Date;

public class StockCars{
  private   String car_name;
  private   String color;
  private   int price;
  private  Date manf_date;
  public StockCars()
  {
      
  }
  public StockCars(String car_name,String color,int price,Date manf_date)
  {
      this.car_name=car_name;
      this.color=color;
      this.price=price;
      this.manf_date=manf_date;
  }
 public String getCarName()
 {
     return car_name;
 }
 public void setName(String car_name)
 {
     this.car_name=car_name;
 }
 public String getColor()
 {
     return color;
 }
 public void setColor(String color)
 {
     this.color=color;
 }
 public int getPrice()
 {
     return price;
 }
 public void setPrice(int price)
 {
     this.price=price;
 }
 public Date getManf_date()
 {
     return manf_date;
 }
 public void setManf_date(Date manf_date)
 {
     this.manf_date=manf_date;
 }
}