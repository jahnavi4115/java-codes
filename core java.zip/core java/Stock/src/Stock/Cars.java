package Stock;
import Stock.*;
import java.io.IOException;
import java.util.*;
public class Cars {
 public static void main(String args[])
         {
 Scanner sc= new Scanner(System.in);
 StockCars car_ob=new StockCars();
 Collection ob=new ArrayList<>();
 List li=(List)ob;
 ArrayList ar=(ArrayList)ob;
 try
     {
 while(true)
               {
 System.out.print("press\n1 present stock \n2 to add element\n3 to remove\nt to exit");
 int choc=sc.nextInt();
 switch(choc)
 {
 case 1:System.out.println("avaliable stock"); 
 
 case 2:System.out.println("enter a new car");
 li.add(sc.nextInt());
 break;
 case 3: System.out.println("enter the element to remove");
 li.remove(sc.nextInt());
 break;
 }
 }
 }
 catch(Exception e)
 {
 System.out.println("all elements");
 }
 for(Object so:ob)
 {
 System.out.println(so);
 }
 }
}