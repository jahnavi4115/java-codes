package com.scholar.entity;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class RegisterScholarData {
	public static void main(String[] args) {
		try{
			Configuration cn=new Configuration();
			SessionFactory sf=cn.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction t=s.beginTransaction();
			ScholarPOJO scholar=new ScholarPOJO();
			scholar.setScholarId(67);
			scholar.setScholarName("hfgdhdfgsfg");
			scholar.setScholarSalary(55000);
			s.save(scholar);
			t.commit();
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
}
