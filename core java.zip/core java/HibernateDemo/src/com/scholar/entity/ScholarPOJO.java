package com.scholar.entity;

public class ScholarPOJO {
	private int scholarId;
    private String scholarName;
    private int scholarSalary;
    public int getScholarId() {
		return scholarId;
	}
	public int getScholarSalary() {
		return scholarSalary;
	}
	public void setScholarSalary(int scholarSalary) {
		this.scholarSalary = scholarSalary;
	}
	public void setScholarId(int scholarId) {
		this.scholarId = scholarId;
	}
	public String getScholarName() {
		return scholarName;
	}
	public void setScholarName(String scholarName) {
		this.scholarName = scholarName;
	}
}
