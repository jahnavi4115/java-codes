package com.student.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.student.model.StudentPOJO;

public class StudentDAO {
	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insert(StudentPOJO studentPOJO){
		String query="insert into studentss values('"+studentPOJO.getId()+"','"+studentPOJO.getName()+"','"+studentPOJO.getMarks()+"')";
		return jdbcTemplate.update(query);
	}
	public int update(StudentPOJO studentPOJO){
		String query="update studentss set name='"+studentPOJO.getName()+"',marks='"+studentPOJO.getMarks()+"' where id='"+studentPOJO.getId()+"' ";
		return jdbcTemplate.update(query);
	}
	public int delete(int id){
		String query="delete from studentss where id='"+id+"' ";
		return jdbcTemplate.update(query);
	}
	public StudentPOJO display(int id){
		String query="Select * from studentss where id=?";
		return jdbcTemplate.queryForObject(query, new Object[]{id},new BeanPropertyRowMapper<StudentPOJO>(StudentPOJO.class));
	}
	public List<StudentPOJO> displayAll(){
		return jdbcTemplate.query("select * from studentss",new RowMapper<StudentPOJO>(){
			public StudentPOJO mapRow(ResultSet rs, int row) throws SQLException {
				StudentPOJO studentPOJO=new StudentPOJO();
				studentPOJO.setId(rs.getInt(1));
				studentPOJO.setName(rs.getString(2));
				studentPOJO.setMarks(rs.getFloat(3));
				return studentPOJO;
			}
		});
	}
}