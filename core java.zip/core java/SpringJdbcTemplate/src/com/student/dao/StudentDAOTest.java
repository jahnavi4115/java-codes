package com.student.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import com.student.model.StudentPOJO;

public class StudentDAOTest {
   StudentDAO studentDAO;
   StudentPOJO studentPOJO;
	public StudentDAOTest() {
		studentDAO=new StudentDAO();
	}
	@Test
	public void testInsert() {
		//fail("Not yet implemented");
		assertNotEquals(0,studentDAO.insert(new StudentPOJO(1,"Jahnavi",98)));
	}

	@Test
	public void testUpdate() {
		//fail("Not yet implemented");
		assertNotEquals(0,studentDAO.update(new StudentPOJO(1,"Jahnavi",98)));
	}

	@Test
	public void testDelete() {
		//fail("Not yet implemented");
		assertNotEquals(0,studentDAO.delete(1));
	}

	@Test
	public void testDisplay() {
		//fail("Not yet implemented");
		assertNotNull(studentDAO.display(1));
	}

	@Test
	public void testDisplayAll() {
		//fail("Not yet implemented");
		assertEquals(3,studentDAO.displayAll().size());
	}

}
