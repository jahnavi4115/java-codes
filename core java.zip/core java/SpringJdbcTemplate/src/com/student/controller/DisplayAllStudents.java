package com.student.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.student.dao.StudentDAO;
import com.student.model.StudentPOJO;

public class DisplayAllStudents {
	private static ApplicationContext applicationContext;

	public static void main(String[] args) {
		applicationContext = new ClassPathXmlApplicationContext("applicationcontext.xml");
		StudentDAO studentDAO=(StudentDAO)applicationContext.getBean("student");
		List<StudentPOJO> studentPOJO=studentDAO.displayAll();
		if(!studentPOJO.isEmpty())
		{
			for(StudentPOJO student:studentPOJO)
			{
				System.out.println(student.getId()+"  "+student.getName()+"  "+student.getMarks());
			}
		}
		else
		{
			System.out.println("No data found");
		}
	}
}
