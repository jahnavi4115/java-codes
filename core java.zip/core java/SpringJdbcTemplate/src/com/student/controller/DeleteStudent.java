package com.student.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.student.dao.StudentDAO;

public class DeleteStudent {
	private static ApplicationContext applicationContext;

	public static void main(String[] args) {
		applicationContext = new ClassPathXmlApplicationContext("applicationcontext.xml");
		StudentDAO studentDAO=(StudentDAO)applicationContext.getBean("student");
		int result=studentDAO.delete(1);
		if(result>0)
			System.out.println("Updated successfully");
		else
			System.out.println("Invalid ID");
	}
}
