package com.student.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.student.dao.StudentDAO;
import com.student.model.StudentPOJO;

public class InsertStudent {
	private static ApplicationContext applicationContext;

	public static void main(String[] args) {
		applicationContext = new ClassPathXmlApplicationContext("applicationcontext.xml");
		StudentDAO studentDao=(StudentDAO)applicationContext.getBean("student");
		StudentPOJO studentPOJO = new StudentPOJO();
		studentPOJO.setId(1);
		studentPOJO.setName("Jahnavi");
		studentPOJO.setMarks(87);
		studentDao.insert(studentPOJO);
		System.out.println("Inserted successfully");
	}
}
