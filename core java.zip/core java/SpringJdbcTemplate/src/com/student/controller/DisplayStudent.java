package com.student.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.student.dao.StudentDAO;
import com.student.model.StudentPOJO;

public class DisplayStudent {
	private static ApplicationContext applicationContext;

	public static void main(String[] args) {
		applicationContext = new ClassPathXmlApplicationContext("applicationcontext.xml");
		StudentDAO studentDAO=(StudentDAO)applicationContext.getBean("student");
		StudentPOJO studentPOJO=studentDAO.display(1);
		if(studentPOJO!=null)
		{
			System.out.println(studentPOJO.getId());
			System.out.println(studentPOJO.getName());
			System.out.println(studentPOJO.getMarks());
		}
		else
		{
			System.out.println("No data found");
		}
	}
}
