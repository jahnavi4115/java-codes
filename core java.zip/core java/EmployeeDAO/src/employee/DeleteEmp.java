package employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.emp.factory.DbFactory;

public class DeleteEmp {
	public static void main(String[] args) {
		Connection con=DbFactory.getConnection();
		try{
			PreparedStatement ps=DbFactory.getConnection().prepareStatement("delete from employee where emp_id=?");
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter id to delete : ");
			int empId=Integer.parseInt(sc.nextLine());
			sc.close();
			ps.setInt(1,empId);
			int result=ps.executeUpdate();
            if(result>0)
            {
            	System.out.println("Record deleted");
            	con.commit();
            	DbFactory.closeConnection();
            }
            else
            {
            	System.out.println("Please enter valid id to delete");
            }
		}
		catch(SQLException s)	
		{
			System.out.println(s);
		}
	}
}
