package com.emp.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.emp.factory.DbFactory;
import com.emp.model.Employee;

public class EmployeeDAO {
   Connection con;
   PreparedStatement ps;
   int result;
   EmployeeDAO()
   {
	   con=DbFactory.getConnection();
   }
   public int addEmployee(Employee e)
   {
	   try{
		   ps=con.prepareStatement("insert into employee values(?,?,?,?,?,?,?,?,?)");
		   ps.setInt(1,e.getEmpId());
		   ps.setString(2,e.getEmpName());
		   ps.setInt(3,e.getEmpSalary());
		   ps.setLong(4,e.getMobileNumber());
		   ps.setString(5,e.getEmailId());
		   ps.setString(6,e.getGender());
		   ps.setString(7,e.getEmpAddress());
		   ps.setDate(8,e.getDoj());
		   ps.setDate(9,e.getDob());
		   result=ps.executeUpdate();
	   }
	   catch(SQLException s)
	   {
		   System.out.println(s);
	   }
	   return result;
   }
}
