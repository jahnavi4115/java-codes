package strings;

import java.util.Random;

public class RandomClassDemo {
   public static void main(String[] args) {
	String s="Jahnavi";
	Random r=new Random();
	int x=r.nextInt(1000);
	System.out.println(s.substring(0,4)+x);
}
}
