package strings;

import java.util.StringTokenizer;

public class StringTokenizerDemo {
  public static void main(String[] args) {
	String s="hello how are u";
	//StringTokenizer st=new StringTokenizer();  //Splits with space
	//StringTokenizer st=new StringTokenizer(s,"h");  //Splits with given Letter and doesn't print that letter
	StringTokenizer st=new StringTokenizer(s,"h",true);  //Splits with given Letter and prints that letter
	while(st.hasMoreTokens())
	{
		System.out.println(st.nextToken());
	}
}
}
