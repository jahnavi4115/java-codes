package strings;

public class PalindromeStringBuffer {
   public static void main(String[] args) {
	   String s="malayalam";
		StringBuffer sb=new StringBuffer(s);
		System.out.println(sb.reverse().toString().equals(s)); 
		int count=0;
		for(int i=100;i<=200;i++)
		{
			String s1=i+"";
			StringBuffer sb1=new StringBuffer(s1);
			if(s1.equals(sb1.reverse().toString()))
			{
				count++;
			}
		}
		System.out.println(count);
}
}
