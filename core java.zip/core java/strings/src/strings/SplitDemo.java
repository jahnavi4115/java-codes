package strings;

public class SplitDemo {
  public static void main(String[] args) {
	String s="Hello!everyone how are you";
	String st[]=s.split(" ");
	for(String s1 : st)
	{
		System.out.println(s1);
	}
}
}
