package strings;

public class StringsBufferDemo {
  public static void main(String[] args) {
	  String s="java";
	StringBuffer sb1=new StringBuffer(s);
	StringBuffer sb2=new StringBuffer(s);
	StringBuffer sb3=sb1;
	System.out.println(sb1.equals(sb2));  // reference comparision
	System.out.println(sb1.equals(sb3));  // reference comparision
	System.out.println(sb1.toString().equals(sb2.toString()));
}
}
