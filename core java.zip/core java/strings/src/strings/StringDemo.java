package strings;

public class StringDemo {
  public static void main(String[] args) {
	String s="hcl";
	String s1=new String("hcl");
	String s3="HCL";
	String s4=new String("HCL");
	String s5="hcl";
	String s6=new String("HCL");
	System.out.println(s==s1);
	System.out.println(s1==s3);
	System.out.println(s==s6);
	System.out.println(s==s5);
	System.out.println(s3==s5);
	System.out.println(s.equals(s1));
	System.out.println(s1.equals(s3));
	System.out.println(s5.equals(s3));
	System.out.println(s3.equals(s4));
	System.out.println(s4.equals(s5));
	System.out.println(s.equals(s6));
	System.out.println(s.equals(s5));
	System.out.println(s3.equals(s5));
	System.out.println(s.hashCode());
	System.out.println(s5.hashCode());
	System.out.println(s.substring(1,2));
}
}
