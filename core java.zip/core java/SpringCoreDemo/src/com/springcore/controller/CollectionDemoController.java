package com.springcore.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.model.Address;
import com.springcore.model.Scholar;

public class CollectionDemoController {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scholar scholar=(Scholar) applicationContext.getBean("scholarAdd");
		List<Address> listOfAddress=scholar.getListOfAddresses();
		System.out.println(scholar.getName()+"  "+scholar.getSapId()+"  "+scholar.getStipend());
		for(Address address:listOfAddress)
		{
			System.out.println(address.getState()+"  "+address.getStreet()+"  "+address.getDoorNo()+"  "+address.getPincode());
		}
	}
}
