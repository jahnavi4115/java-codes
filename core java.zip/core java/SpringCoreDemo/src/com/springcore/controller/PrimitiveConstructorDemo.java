package com.springcore.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.model.Scholar;

public class PrimitiveConstructorDemo {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scholar scholar=(Scholar) applicationContext.getBean("scho");
		System.out.println(scholar.getSapId()+" "+scholar.getName()+" "+scholar.getStipend());
	}
}
