package com.springcore.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.model.Scholar;

public class ReferenceDemoController {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scholar scholarAddress=(Scholar) applicationContext.getBean("schAdd");
		System.out.println(scholarAddress.getSapId()+" "+scholarAddress.getName()+" "+scholarAddress.getStipend());
		System.out.println(scholarAddress.getAddress().getDoorNo()+" "+scholarAddress.getAddress().getStreet()+" "+scholarAddress.getAddress().getState()+" "+scholarAddress.getAddress().getPincode());
	}
}
