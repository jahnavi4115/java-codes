package com.springcore.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.model.Scholar;

public class PrimitiveDemoController {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Scholar scholar=(Scholar) applicationContext.getBean("scholar");
		System.out.println(scholar.getSapId()+" "+scholar.getName()+" "+scholar.getStipend());
	}
}
