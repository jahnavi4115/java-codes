package com.springcore.controller;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.springcore.model.Test;

public class TestController {
	public static void main(String[] args) {
       ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
       Test test=(Test) applicationContext.getBean("test");
       test.scholar();
	}
}
