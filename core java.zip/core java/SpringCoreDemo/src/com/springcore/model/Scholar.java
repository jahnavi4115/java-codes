package com.springcore.model;

import java.util.List;

public class Scholar {
	private int sapId;
	private String name;
	private float stipend;
	private Address address;
	 private List<Address> listOfAddresses;
	public List<Address> getListOfAddresses() {
		return listOfAddresses;
	}
	public void setListOfAddresses(List<Address> listOfAddresses) {
		this.listOfAddresses = listOfAddresses;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public int getSapId() {
		return sapId;
	}
	public void setSapId(int sapId) {
		this.sapId = sapId;
	}
	public String getName() {
		return name;
	}
	public Scholar(int sapId, String name, float stipend) {
		super();
		this.sapId = sapId;
		this.name = name;
		this.stipend = stipend;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Scholar(int sapId, String name, float stipend, Address address) {
		super();
		this.sapId = sapId;
		this.name = name;
		this.stipend = stipend;
		this.address = address;
	}
	public float getStipend() {
		return stipend;
	}
	public void setStipend(float stipend) {
		this.stipend = stipend;
	}

}
