package com.springcore.model;

public class Test {
  public void scholar()
  {
	  System.out.println("Jahnavi");
  }
}
