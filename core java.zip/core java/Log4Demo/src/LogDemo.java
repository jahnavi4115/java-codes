import java.io.IOException;
import java.sql.SQLException;



import org.apache.log4j.Logger;



public class LogDemo {
	static Logger log = Logger.getLogger(LogDemo.class.getName());
	public static void main(String[] args)throws IOException,SQLException {
		log.debug("Debug Message");
		log.info("Info Message");
		log.warn("warn message");
		log.error("Error message");
		log.fatal("Fatal message");
		System.out.println("done");
		add(5,2);
		div(6,3);
	}
	static void add(int x,int y)
	{
		System.out.println(x+y);
		log.info("Added Two Numbers");
	}
	static void div(int x,int y)
	{
		try{
			System.out.println(x/y);
			log.info("Divison done");
			log.warn("Denominator should not be zero");
		}
		catch(ArithmeticException e)
		{
			log.error(e);
			log.warn("Caught by Exception");
		}
	}
}