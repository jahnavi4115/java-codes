import org.apache.log4j.Logger;
public class Calculator {
	static Logger log = Logger.getLogger(Calculator.class.getName());

	 public static void main(String[] args) {

	 add(12,2);

	 sub(23,4);

	 mul(3,20);

	 div(24,8);

	 rem(2,2);

	 }

	 static int add(int x,int y)

	 {

	 log.info("Added Two Numbers");

	 return(x+y);

	 }

	 static int sub(int x,int y)

	 {

	 log.info("Subtracted Two Numbers");

	 return(x-y);

	 }

	 static int mul(int x,int y)

	 {

	 log.info("Multiplied Two Numbers");

	 return(x*y);

	 }

	 static int div(int x,int y)

	 {

	 try{

	 log.info("Divided Two Numbers");

	 log.warn("Denominator should not be zero");

	 }

	 catch(ArithmeticException e)

	 {

	 log.error(e);

	 }

	 return(x/y);

	 }

	 static int rem(int x,int y)

	 {

	 log.info("Remainder Of Two Numbers");

	 return(x%y);

	 }
}
