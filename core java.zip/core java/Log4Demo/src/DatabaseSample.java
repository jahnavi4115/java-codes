import org.apache.log4j.Logger;
 
public class DatabaseSample{

    /* Get actual class name to be printed on */

    public static Logger log = Logger.getLogger(DatabaseSample.class.getName());


    public static void main(String[] args)

    {
 
       log.debug("Sample debug message");

        log.info("Sample info message");

        log.fatal("Sample fatal message");

    }

 }