import java.util.Scanner;

public class BinarySearch {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
        System.out.println("Enter size : ");
        int size=sc.nextInt();
		int arr[]=new int[size];
        for(int i=0;i<size;i++)
        {
        	arr[i]=sc.nextInt();
        }
        for(int i=0;i<size;i++)
        {
        	for(int j=1;j<size-i;j++)
        	{
        		if(arr[j]<arr[j-1])
        		{
        			int temp=arr[j];
        			arr[j]=arr[j-1];
        			arr[j-1]=temp;
        		}
        	}
        }
        for(int i=0;i<size;i++)
        {
        	System.out.println(arr[i]);
        } 
        System.out.println("Enter num :");
        int x=sc.nextInt();
        int min=0,max=size-1;       
        while(min<=max)
        {
        	 int mid=(min+max)/2;
        	if(x==arr[mid])
        	{
        		System.out.println(mid+" "+arr[mid]);
        		break;
        	}
        	else if(x>arr[mid])
        	{
        		min=mid+1;
        	}                                                    	                                                     
        	else
        	{
        		max=mid-1;
        	}
        }
        if(min>max)
        {
        	System.out.println("Not found");
        }
    }
}
