import java.util.Scanner;

public class FebbonocciSeries {
	public static void main(String[] args) {
           //0,1,1,2,3,5,8,11
		Scanner sc=new Scanner(System.in);
        System.out.println("Enter size : ");
        int n=sc.nextInt();
        int a=0,b=1,c;
        for(int count=0;count<n;count++)
        {
        	System.out.println(a);
        	c=a+b;
        	a=b;
        	b=c;
        }
        sc.close();
	}
}
