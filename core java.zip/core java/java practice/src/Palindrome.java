import java.util.Scanner;

public class Palindrome {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
        System.out.println("Enter num : ");
        int num=sc.nextInt();  
        int quo=num,sum=0;       
        while(quo>0)
        {
        	int rem=quo%10;
        	sum=sum*10+rem;  
        	quo=quo/10;
        }
        if(num==sum)
        	System.out.println("pa");
        else
        	System.out.println("not");
        sc.close();
	}
}
