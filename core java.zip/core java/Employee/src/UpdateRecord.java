

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.dao.EmployeeDAO;
import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class UpdateLogin
 */
public class UpdateRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//int empId=Integer.parseInt(request.getParameter("id"));
		/*HttpSession session=request.getSession(true);
		if(session.getAttribute("key")!=null || session!=null)
		{
			int empId=(int)session.getAttribute("key");
			String password=request.getParameter("password");
			try{
				Class.forName("oracle.jdbc.driver.OracleDriver"); 
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system"); 
				PreparedStatement ps=con.prepareStatement( "update emp set password=? where id=?"); 
				ps.setString(1,password);
				ps.setInt(2,empId);
				int r=ps.executeUpdate();
				PrintWriter out=response.getWriter();
				if(r>0)
				{
					out.println("<font color='green'>Updated Successfully</font>");
					RequestDispatcher rd=request.getRequestDispatcher("Home.html");
					rd.include(request,response);
				}
			}
			catch(ClassNotFoundException c)
			{
				System.out.println(c);
			}
			catch(SQLException s)
			{
				System.out.println(s);
			}
		}*/
		EmployeeVo employeeVo=new EmployeeVo();
		HttpSession session=request.getSession(true);
		if(session.getAttribute("key")!=null || session!=null)
		{
			int empId=(int)session.getAttribute("key");
			String password=request.getParameter("password");
			employeeVo.setEmpId(empId);
			employeeVo.setPassword(password);
			int result=EmployeeDAO.updateEmployee(employeeVo);
			PrintWriter out=response.getWriter();
			if(result>0)
			{
				out.println("Updated Successfully");
			}

		}
	}

}
