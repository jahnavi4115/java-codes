package com.emp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.dao.EmployeeDAO;
import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class FindAllEmployeeController
 */
public class FindAllEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		List<EmployeeVo> listofEmployees=EmployeeDAO.displayAll();
		PrintWriter out=response.getWriter();			
			if(!listofEmployees.isEmpty())
			{
				request.setAttribute("k",listofEmployees);
				RequestDispatcher rd=request.getRequestDispatcher("JstlDisplayAll.jsp");
				rd.forward(request,response);
			}
			else
			{
				out.println("No data available");
			}
		}
	}


