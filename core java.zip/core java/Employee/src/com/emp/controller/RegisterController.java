package com.emp.controller;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.dao.EmployeeDAO;
import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class RegisterController
 */
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeVo employeeVo=new EmployeeVo();
		int empId=Integer.parseInt(request.getParameter("id"));
		String empName=request.getParameter("Name");
		int empSalary=Integer.parseInt(request.getParameter("salary"));
		long empMobile=Long.parseLong(request.getParameter("mobile"));
		String empEmail=request.getParameter("emailid");
		String empGender=request.getParameter("gender");
		String empAddress=request.getParameter("address");
		String password=request.getParameter("password");
		try{
			String date1=request.getParameter("dob");
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date jd=sdf.parse(date1);
			java.sql.Date empDOB=new Date(jd.getTime());
			String date2=request.getParameter("doj");
			java.util.Date jd1=sdf.parse(date2);
			java.sql.Date empDOJ=new Date(jd1.getTime());
			employeeVo.setEmpId(empId);
			employeeVo.setEmpName(empName);
			employeeVo.setEmpSalary(empSalary);
			employeeVo.setMobileNumber(empMobile);
			employeeVo.setEmailId(empEmail);
			employeeVo.setGender(empGender);
			employeeVo.setEmpAddress(empAddress);
			employeeVo.setDoj(empDOJ);
			employeeVo.setDob(empDOB);
			employeeVo.setPassword(password);
			int result=EmployeeDAO.insertEmployee(employeeVo);
			if(result>0)
			{
				response.sendRedirect("Login.html");
			}
		}
		catch(ParseException p)
		{
			System.out.println(p);
		}
		}
	}
