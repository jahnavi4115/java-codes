package com.emp.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.dao.EmployeeDAO;
import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class FindEmployeeController
 */
public class FindEmployeeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeVo employeeVo;
		HttpSession session=request.getSession(true);
		if(session.getAttribute("key")!=null || session!=null)
		{
			int empId=(int)session.getAttribute("key");
			employeeVo=new EmployeeVo();
			employeeVo.setEmpId(empId);
			EmployeeVo emp=EmployeeDAO.findEmployee(employeeVo.getEmpId());
			if(emp!=null)
			{
				request.setAttribute("empKey",emp);
				RequestDispatcher rd=request.getRequestDispatcher("DisplayEmployee.jsp");
				rd.forward(request,response);
			}
		}
	}

}
