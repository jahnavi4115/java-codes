package com.employee.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.employee.factory.DbFactory;
import com.employee.model.EmployeeVo;

public class EmployeeDAO {
	static Connection connection;
	static PreparedStatement preparedStatement;
	static int result;
	static ResultSet resultSet;
	static EmployeeVo employeeVo;
	static boolean check=false;
	static List<EmployeeVo> listOfEmployees;
	static String empName;
	static
	{
		connection=DbFactory.getOracleConnection();
		
	}
	public static int insertEmployee(EmployeeVo emp)
	{
		try{
			preparedStatement=connection.prepareStatement("insert into emp values(?,?,?,?,?,?,?,?,?,?)");
			preparedStatement.setInt(1,emp.getEmpId());
			preparedStatement.setString(2,emp.getEmpName());
			preparedStatement.setInt(3,emp.getEmpSalary());
			preparedStatement.setLong(4,emp.getMobileNumber());
			preparedStatement.setString(5,emp.getEmailId());
			preparedStatement.setString(6,emp.getGender());
			preparedStatement.setString(7,emp.getEmpAddress());
			preparedStatement.setDate(8,emp.getDoj());
			preparedStatement.setDate(9,emp.getDob());
			preparedStatement.setString(10,emp.getPassword());
			result=preparedStatement.executeUpdate();
			if(result>0)
			{
				connection.commit();
				DbFactory.closeAll(preparedStatement, connection);
			}
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		return result;
	}
	public static int updateEmployee(EmployeeVo emp)
	{
		try{
			preparedStatement=connection.prepareStatement("update emp set password=? where id=?");
			preparedStatement.setString(1,emp.getPassword());
			preparedStatement.setInt(2,emp.getEmpId());
			result=preparedStatement.executeUpdate();
			if(result>0)
			{
				connection.commit();
				//DbFactory.closeAll(preparedStatement, connection);
			}
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		return result;
	}
	public static int deleteEmployee(EmployeeVo emp)
	{
		try{
			preparedStatement=connection.prepareStatement("delete from emp where id=?");
			preparedStatement.setInt(1,emp.getEmpId());
			result=preparedStatement.executeUpdate();
			if(result>0)
			{
				connection.commit();
				DbFactory.closeAll(preparedStatement, connection);
			}
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		return result;
	}
	public static EmployeeVo findEmployee(int empId)
	{  	
		try{   		  		
			preparedStatement=connection.prepareStatement("select * from emp where id=?");
			preparedStatement.setInt(1,empId);
			resultSet=preparedStatement.executeQuery();		
			if(resultSet.next())
			{
				employeeVo=new EmployeeVo();
				employeeVo.setEmpId(resultSet.getInt(1));
				employeeVo.setEmpName(resultSet.getString(2));
				employeeVo.setEmpSalary(resultSet.getInt(3));
				employeeVo.setMobileNumber(resultSet.getLong(4));
				employeeVo.setEmailId(resultSet.getString(5));
				employeeVo.setGender(resultSet.getString(6));			
				employeeVo.setEmpAddress(resultSet.getString(7));				
				employeeVo.setDoj(resultSet.getDate(8));
				employeeVo.setDob(resultSet.getDate(9));
				//DbFactory.closeAll(preparedStatement, connection);
			}    		
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		return employeeVo;
	}
	public static List<EmployeeVo> displayAll()
	{
		listOfEmployees=new ArrayList<EmployeeVo>();
		try{   		
			preparedStatement=connection.prepareStatement("select * from emp");
			resultSet=preparedStatement.executeQuery();	
			while(resultSet.next())
			{
				employeeVo=new EmployeeVo();
				employeeVo.setEmpId(resultSet.getInt(1));
				employeeVo.setEmpName(resultSet.getString(2));
				employeeVo.setEmpSalary(resultSet.getInt(3));
				employeeVo.setMobileNumber(resultSet.getLong(4));
				employeeVo.setEmailId(resultSet.getString(5));
				employeeVo.setGender(resultSet.getString(6));			
				employeeVo.setEmpAddress(resultSet.getString(7));				
				employeeVo.setDoj(resultSet.getDate(8));
				employeeVo.setDob(resultSet.getDate(9));
				listOfEmployees.add(employeeVo);
			}
			if(!listOfEmployees.isEmpty())
			{
				DbFactory.closeAll(preparedStatement, connection);
			}
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		return listOfEmployees;
	}
	public static boolean authentication(EmployeeVo emp)
	{
		try{
			preparedStatement=connection.prepareStatement("select * from emp where id=? and password=?");
			preparedStatement.setInt(1,emp.getEmpId());
			preparedStatement.setString(2,emp.getPassword());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				check=true;
			}
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		return check;
	}
	public static String authenticationWithName(EmployeeVo emp)
	{
		try{
			preparedStatement=connection.prepareStatement("select name from emp where id=? and password=?");
			preparedStatement.setInt(1,emp.getEmpId());
			preparedStatement.setString(2,emp.getPassword());
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				empName=resultSet.getString(1);
				System.out.println(empName);
				//DbFactory.closeAll(preparedStatement, connection);		
			}
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}
		return empName;
	}
}
