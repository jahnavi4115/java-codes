package com.employee.factory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DbFactory {
	static DataSource dataSource;
	static Connection connection;
	static{
		try{
			Context initContext= new InitialContext();
			dataSource=(DataSource)initContext.lookup("java:comp/env/jdbc/EMPDB");
		}
		catch(NamingException ne){
			System.out.println(ne);
		}
	}
	public static Connection getOracleConnection()
	{
		try {
			connection=dataSource.getConnection();
			if(connection!=null)
				connection.setAutoCommit(false);
		} 
		catch (SQLException se) {
			System.out.println(se);
		}
		return connection;	
	}
	public static void closeAll(PreparedStatement preparedStatement,Connection connection)
	{
		if(connection!=null)
		{
			try{
				connection.close();
			}
			catch(SQLException se){
				System.out.println(se);
			}
		}
		if(preparedStatement!=null)
		{
			try{
				preparedStatement.close();
			}
			catch (SQLException se){
				System.out.println(se);
			}
		}
	}
}
