

import java.io.IOException;
import java.io.PrintWriter;
//import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class Display
 */
public class DisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List<EmployeeVo> li=(List<EmployeeVo>) request.getAttribute("k");
		PrintWriter out=response.getWriter();  
		for(EmployeeVo e:li)
		{
			out.println(e.getEmpId());
			out.println(e.getEmpName());
			out.println(e.getEmpSalary());
			out.println(e.getGender());
			out.println(e.getMobileNumber());
			out.println(e.getEmpAddress());
			out.println(e.getEmailId());
			out.println(e.getDoj());
			out.println(e.getDob());
		}
	}

}
