

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Servlet Filter implementation class CheckNameFiler
 */
public class CheckNameFiler implements Filter {

    /**
     * Default constructor. 
     */
    public CheckNameFiler() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		//chain.doFilter(request, response);
		String name=request.getParameter("name");
		List<String> l=new ArrayList<String>();
		l.add("HCL");
		l.add("Infosys");
		l.add("vipro");
		if(l.contains(name))
		{
		    chain.doFilter(request,response);
		    response.getWriter().print(name+" is in the list");
		}
		else
		{
			response.getWriter().print(name+" is not in the organizations list");
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
