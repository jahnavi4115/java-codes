import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;

public class Demo {
public static void main(String[] args) {
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system"); 
		System.out.println("Connection Established");
		PreparedStatement ps=con.prepareStatement( "delete emp where id=?"); 
		ps.setInt(1,12);
		int r=ps.executeUpdate();
		if(r>0)
		{
			System.out.println("Record Deleted");
			con.commit();
		}
		else
		{
			System.out.println("Record not Deleted");
		}
	}
	catch(ClassNotFoundException c)
	{
		System.out.println(c);
	}
	catch(SQLException s)
	{
		System.out.println(s);
	
}
}}
