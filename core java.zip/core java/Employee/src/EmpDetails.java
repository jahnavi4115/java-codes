


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class EmployeRegistration
 */
public class EmpDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeVo e=new EmployeeVo();
		int empId=Integer.parseInt(request.getParameter("id"));
		String empName=request.getParameter("Name");
		int empSalary=Integer.parseInt(request.getParameter("salary"));
		long empMobile=Long.parseLong(request.getParameter("mobile"));
		String empEmail=request.getParameter("emailid");
		String empGender=request.getParameter("gender");
		String empAddress=request.getParameter("address");
		String password=request.getParameter("password");
		e.setEmpId(empId);
		e.setEmpName(empName);
		e.setEmpSalary(empSalary);
		e.setMobileNumber(empMobile);
		e.setEmailId(empEmail);
		e.setGender(empGender);
		e.setEmpAddress(empAddress);
		e.setPassword(password);
		try{
			String date1=request.getParameter("dob");
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date jd=sdf.parse(date1);
			java.sql.Date empDOB=new Date(jd.getTime());
			String date2=request.getParameter("doj");
			java.util.Date jd1=sdf.parse(date2);
			java.sql.Date empDOJ=new Date(jd1.getTime());
			e.setDoj(empDOJ);
			e.setDob(empDOB);
				Class.forName("oracle.jdbc.driver.OracleDriver"); 
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system"); 
				PreparedStatement ps=con.prepareStatement( "insert into emp values(?,?,?,?,?,?,?,?,?,?)"); 	 
				ps.setInt(1,empId);
				ps.setString(2,empName);
				ps.setInt(3,empSalary);
				ps.setLong(4,empMobile);
				ps.setString(5,empEmail);
				ps.setString(6,empGender);
				ps.setString(7,empAddress);
				ps.setDate(8,empDOJ);
				ps.setDate(9,empDOB);	
				ps.setString(10,password);
				int i=ps.executeUpdate(); 
				PrintWriter out=response.getWriter();
				if(i>0) 
				{
					out.println("Inserted");
					con.commit();
					/*request.setAttribute("k",e);
					RequestDispatcher rd=request.getRequestDispatcher("Display");
					rd.forward(request,response);*/
				}
			}
		catch(ParseException p)
		{
			System.out.println(p);
		}
		   catch(ClassNotFoundException c)
		   {
			 System.out.println(c);  
		   }
		catch(SQLException s)
		{
			System.out.println(s);
		}
	}

}
