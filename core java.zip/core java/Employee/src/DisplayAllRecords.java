

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class UpdateLogin
 */
public class DisplayAllRecords extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeVo e;
		List<EmployeeVo> l=new ArrayList<EmployeeVo>();
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system"); 
			PreparedStatement ps=con.prepareStatement( "select * from emp"); 
			ResultSet rs=ps.executeQuery();
			PrintWriter out=response.getWriter();
			while(rs.next())
			{
				e=new EmployeeVo();
				e.setEmpId(rs.getInt(1));
				e.setEmpName(rs.getString(2));
				e.setEmpSalary(rs.getInt(3));
				e.setMobileNumber(rs.getLong(4));
				e.setEmailId(rs.getString(5));
				e.setGender(rs.getString(6));			
				e.setEmpAddress(rs.getString(7));				
				e.setDoj(rs.getDate(8));
				e.setDob(rs.getDate(9));
				l.add(e);
			}
			if(!l.isEmpty())
			{
				request.setAttribute("k",l);
				RequestDispatcher rd=request.getRequestDispatcher("JstlDisplayAll.jsp");
				rd.forward(request,response);
			}
			else
			{
				out.println("No data available");
			}
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
		catch(SQLException s)
		{
			System.out.println(s);
		}
	}

}
