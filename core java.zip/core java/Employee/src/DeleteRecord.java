

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UpdateLogin
 */
public class DeleteRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int empId=Integer.parseInt(request.getParameter("id"));
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system"); 
			PreparedStatement ps=con.prepareStatement( "delete emp where id=?"); 
			ps.setInt(1,empId);
			int r=ps.executeUpdate();
			PrintWriter out=response.getWriter();
			if(r>0)
			{
				out.println("Record Deleted");
				con.commit();
			}
			else
			{
				out.println("<font color='red'>Please enter valid employee id</font>");
				RequestDispatcher rd=request.getRequestDispatcher("DeleteRecords.html");
				rd.include(request,response);
			}
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
		catch(SQLException s)
		{
			System.out.println(s);
		}
	}

}
