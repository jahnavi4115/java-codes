import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
/*import java.sql.ResultSet;
import java.sql.SQLException;*/

/*import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;*/
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.sql.DataSource;

import com.employee.factory.DbFactory;







/**
 * Servlet implementation class ConnectionPoolDemo
 */
public class ConnectionPoolingDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;







	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*try{
			Connection connection=DbFactory.getOracleConnection();
			System.out.println("connected" + connection);
			PreparedStatement preparedStatement=null;
			/*PreparedStatement preparedStatement=connection.prepareStatement("select * from emp");
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				response.getWriter().print(" "+rs.getInt(1) + " "+rs.getString(2)+ " "+rs.getInt(3)+"<br>");
			}
			DbFactory.closeAll(preparedStatement, connection);
		}
		catch(SQLException se)
		{
			System.out.println(se);
		}*/
		Connection connection=DbFactory.getOracleConnection();
		System.out.println("connected" + connection);
		PreparedStatement preparedStatement=null;
		DbFactory.closeAll(preparedStatement, connection);
		System.out.println("closed");
	}







}