

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.employee.model.EmployeeVo;

/**
 * Servlet implementation class UpdateLogin
 */
public class FindRecord extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EmployeeVo e;
		HttpSession session=request.getSession(true);
		if(session.getAttribute("key")!=null || session!=null)
		{
			int empId=(int)session.getAttribute("key");
			try{
				Class.forName("oracle.jdbc.driver.OracleDriver"); 
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system"); 
				PreparedStatement ps=con.prepareStatement( "select * from emp where id=?"); 
				ps.setInt(1,empId);
				ResultSet rs=ps.executeQuery();		
				if(rs.next())
				{
					e=new EmployeeVo();
					e.setEmpId(rs.getInt(1));
					e.setEmpName(rs.getString(2));
					e.setEmpSalary(rs.getInt(3));
					e.setMobileNumber(rs.getLong(4));
					e.setEmailId(rs.getString(5));
					e.setGender(rs.getString(6));			
					e.setEmpAddress(rs.getString(7));				
					e.setDoj(rs.getDate(8));
					e.setDob(rs.getDate(9));
					request.setAttribute("empKey",e);
					RequestDispatcher rd=request.getRequestDispatcher("DisplayEmployee.jsp");
					rd.forward(request,response);
				}
			}
			catch(ClassNotFoundException c)
			{
				System.out.println(c);
			}
			catch(SQLException s)
			{
				System.out.println(s);
			}
		}
	}

}
