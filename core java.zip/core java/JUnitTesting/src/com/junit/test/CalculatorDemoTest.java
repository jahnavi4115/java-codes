package com.junit.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorDemoTest {
	CalculatorDemo calculatorDemo;
	   public CalculatorDemoTest() {
		// TODO Auto-generated constructor stub
		   calculatorDemo=new CalculatorDemo();
	   }
	@Test
	public void testConcat() {
		//fail("Not yet implemented");
		assertEquals("jahnavi",calculatorDemo.concat("jah","navi"));
	}

	@Test
	public void testSquareArea() {
		//fail("Not yet implemented");
		assertEquals(4,calculatorDemo.squareArea(2));
	}

	@Test
	public void testSquarePerimeter() {
		//fail("Not yet implemented");
		assertEquals(8,calculatorDemo.squarePerimeter(2));
	}

}
