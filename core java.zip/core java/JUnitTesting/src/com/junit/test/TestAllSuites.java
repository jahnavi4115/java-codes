package com.junit.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	CalculatorDemoTest.class,
	CalculatorTest.class
}

		)

public class TestAllSuites {

}
