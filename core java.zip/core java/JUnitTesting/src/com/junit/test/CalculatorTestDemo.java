package com.junit.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;


public class CalculatorTestDemo {
	
	static Calculator c;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Object Created");
		c=new Calculator();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Object destoyed");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Before method executed");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("After method executed");
	}

	@Test
	public void testAdd() {
		//fail("Not yet implemented");
		assertEquals(10,c.add(6,4));
	}

	@Test
	public void testSub() {
		//fail("Not yet implemented");
		assertEquals(10,c.sub(20,10));
	}

	@Test
	public void testMul() {
		//fail("Not yet implemented");
		assertEquals(10,c.mul(5,2));
	}

	@Test
	public void testDiv() {
		//fail("Not yet implemented");
		assertEquals(10,c.div(100,10));
	}

	@Test
	public void testRem() {
		//fail("Not yet implemented");
		assertEquals(0,c.rem(4,2));
	}

	@Test
	public void testAuthenticate() {
		//fail("Not yet implemented");
		assertTrue(c.authenticate("Jahnavi", "Janu@123"));
	}

	@Test
	public void testGetStudent() {
		//fail("Not yet implemented");
		assertNotNull(c.getStudent(1234));
	}

	@Test
	public void testDisplayAll() {
		//fail("Not yet implemented");
		assertEquals(3,c.displayAll().size());
	}

}
