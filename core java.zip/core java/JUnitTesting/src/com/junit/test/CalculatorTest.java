package com.junit.test;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

public class CalculatorTest {
	Calculator c;
	public CalculatorTest()
	{
		c=new Calculator();
	}
	@Test
	public void testAdd() {
		//fail("Not yet implemented");
		assertEquals(10,c.add(6,4));
	}

	@Test
	public void testSub() {
		//fail("Not yet implemented");
		assertEquals(10,c.sub(20,10));
	}
	@Ignore
	@Test
	public void testMul() {
		//fail("Not yet implemented");
		assertEquals(12,c.mul(5,2));
	}

	@Test(expected=ArithmeticException.class)
	public void testDiv() {
		//fail("Not yet implemented");
		assertEquals(0,c.div(100,0));
	}

	@Test
	public void testRem() {
		//fail("Not yet implemented");
		assertEquals(0,c.rem(4,2));
	}

	@Test
	public void testAuthenticate() {
		//fail("Not yet implemented");
		assertTrue(c.authenticate("Jahnavi", "Janu@123"));
	}

	@Test
	public void testGetStudent() {
		//fail("Not yet implemented");
		assertNotNull(c.getStudent(1234));
	}

	@Test
	public void testDisplayAll() {
		//fail("Not yet implemented");
		assertEquals(3,c.displayAll().size());
	}

}
