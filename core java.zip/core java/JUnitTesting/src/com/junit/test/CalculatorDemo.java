package com.junit.test;

public class CalculatorDemo {
	public String concat(String x,String y)
	{
		return(x+y);
	}
    public int squareArea(int a)
    {
        return a*a;
    }
      public int squarePerimeter(int a){      
        return 4*a;     
    }
}
