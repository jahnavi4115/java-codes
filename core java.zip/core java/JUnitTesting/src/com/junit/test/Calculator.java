package com.junit.test;


import java.util.ArrayList;
import java.util.List;

import com.junit.test.Student;

public class Calculator {
	public int add(int x,int y)
	{
		return(x+y);
	}
	public int sub(int x,int y)
	{
		return(x-y);
	}
	public int mul(int x,int y)
	{
		return(x*y);
	}
	public int div(int x,int y)
	{
		return(x/y);
	}
	public int rem(int x,int y)
	{
		return(x%y);
	}
	public boolean authenticate(String userName,String password)
	{
		boolean check=false;
		if(userName.equals("Jahnavi") && password.equals("Janu@123"))
			check=true;
		return check;
	}
	public Student getStudent(int studentId)
	{
		Student s=null;
		if(studentId==1234)
			s=new Student(1234,"Jahnavi",89.9f);
		return s;
	}
	public List<Student> displayAll()
	{
		Student s=new Student(1,"Janu",87.6f);
		Student s1=new Student(2,"Daksha",86.5f);
		Student s2=new Student(3,"Honey",92.5f);
		List<Student> liStudents=new ArrayList<Student>();
		liStudents.add(s);
		liStudents.add(s1);
		liStudents.add(s2);
		return liStudents;
	}
}
