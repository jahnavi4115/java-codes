package com.json;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONValue;

public class JSONEncodeMapDemo {
	 public static void main(String args[]){    
         Map obj=new HashMap();    
         obj.put("name","Jahnavi");    
         obj.put("age",new Integer(19));    
         obj.put("salary",new Double(100000));   
         String jsonText = JSONValue.toJSONString(obj);  
         System.out.print(jsonText);  
       }   
}
