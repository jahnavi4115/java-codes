package com.json;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONValue;

import com.json.model.Scholar;

public class JSONListScholar {
      public static void main(String[] args) {
		List<Scholar> listOfScholars=new ArrayList<Scholar>();
		listOfScholars.add(new Scholar(51834504,"Jahnavi",10000));
		listOfScholars.add(new Scholar(51834503,"Dakshayani",10000));
		listOfScholars.add(new Scholar(51834502,"Haneesha",10000));
		String jsonList = JSONValue.toJSONString(listOfScholars); 
		for(Scholar scholar: listOfScholars)
	        System.out.println(scholar.getSapId()+" "+scholar.getName()+" "+scholar.getStipend());
      }
}
