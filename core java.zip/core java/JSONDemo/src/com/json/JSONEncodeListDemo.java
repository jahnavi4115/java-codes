package com.json;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONValue;


public class JSONEncodeListDemo {
	 public static void main(String[] args) {
	        List list=new ArrayList();
	        list.add("Jahnavi");
	        list.add(new Integer(19));
	        list.add(new Double(80000));
	        String listonText = JSONValue.toJSONString(list); 
	        System.out.println(list);
	    }
}
