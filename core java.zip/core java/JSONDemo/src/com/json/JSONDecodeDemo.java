package com.json;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

public class JSONDecodeDemo {
	public static void main(String[] args) {
	    String s="{\"name\":\"Jahnavi\",\"age\":19,\"location\":\"Guntur\"}";
	     Object obj=JSONValue.parse(s);  
	        JSONObject jsonObject = (JSONObject) obj;  
	      
	        String name = (String) jsonObject.get("name");  
	        String location = (String) jsonObject.get("location");  
	        long age = (Long) jsonObject.get("age");  
	        System.out.println(name+" "+age+" "+location);  
	}
}
