package com.json;

import org.json.simple.JSONArray;

public class JSONEncodeArrayDemo {
	public static void main(String args[]){    
		JSONArray arr = new JSONArray();  
		arr.add("Jahnavi");    
		arr.add(new Integer(18));    
		arr.add(new Double(60000));   
		System.out.print(arr);  
	}
}