package com.json.model;

public class Scholar {
	private int sapId;
	private String name;
	private float stipend;
	public int getSapId() {
		return sapId;
	}
	public void setSapId(int sapId) {
		this.sapId = sapId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getStipend() {
		return stipend;
	}
	public Scholar(int sapId, String name, float stipend) {
		super();
		this.sapId = sapId;
		this.name = name;
		this.stipend = stipend;
	}
	public void setStipend(float stipend) {
		this.stipend = stipend;
	}
}
