package com.json;

import org.json.simple.JSONObject;

public class JSONEncodeDemo {
	public static void main(String args[]){    
        JSONObject json=new JSONObject();    
          json.put("name","Jahnavi");    
          json.put("age",new Integer(19));    
          json.put("salary",new Double(90000));    
           System.out.print(json);    
        }

 
}
