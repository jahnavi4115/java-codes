
class B {

	public static void main(String[] args) {
	
	}

}
