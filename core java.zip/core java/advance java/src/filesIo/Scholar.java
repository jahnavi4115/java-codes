package filesIo;

import java.io.Serializable;

public class Scholar implements Serializable{
	private int schId;
	private String schName;
	transient private int schMarks;
   public Scholar(int schId, String schName, int schMarks) {
		super();
		this.schId = schId;
		this.schName = schName;
		this.schMarks = schMarks;
	}

   public int getSchId() {
	return schId;
}
public void setSchId(int schId) {
	this.schId = schId;
}
public String getSchName() {
	return schName;
}
public void setSchName(String schName) {
	this.schName = schName;
}
public int getSchMarks() {
	return schMarks;
}
public void setSchMarks(int schMarks) {
	this.schMarks = schMarks;
}

}
