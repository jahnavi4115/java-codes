package filesIo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class RetrieveScholar {
   public static void main(String[] args) {
	   try
	   {
		   File f=new File("C:\\Jahnavi IO\\Sample3.txt");
		   FileInputStream fi=new FileInputStream(f);
		   ObjectInputStream o=new ObjectInputStream(fi);
		   Scholar s=(Scholar)(o.readObject());
		   if(s!=null)
		   {
			   System.out.println(s.getSchId());
			   System.out.println(s.getSchName());
			   System.out.println(s.getSchMarks());
		   }
		   o.close();
	   }
	   catch(ClassNotFoundException c)
	   {
		   System.out.println(c);
	   }
	   catch(FileNotFoundException f)
	   {
		   System.out.println(f);
	   }
	   catch(IOException i)
	   {
		   System.out.println(i);
	   }	
}
}
