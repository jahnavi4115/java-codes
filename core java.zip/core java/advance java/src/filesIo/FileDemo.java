package filesIo;

import java.io.File;
import java.io.IOException;

public class FileDemo {
   public static void main(String[] args) {
	File f=new File("C:\\Users\\obulasetty.jahnavi\\Downloads\\Email.docx");
	System.out.println(f.exists());
	if(f.exists())
	{
		System.out.println(f.getPath());
		System.out.println(f.getParent());
		System.out.println(f.getName());
		System.out.println(f.getAbsolutePath());
		System.out.println(f.canRead());
		System.out.println(f.canWrite());
		f.delete();
	}
	else
	{
		try
		{
			System.out.println(f.createNewFile());
		}
		catch(IOException ie)
		{
			System.out.println("Exception");
		}
	}
}
}
