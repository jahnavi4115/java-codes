package filesIo;

import java.io.CharArrayReader;
import java.io.IOException;

public class CharArrayReaderDemo {
  public static void main(String[] args) {
	char ch[]={'j','a','v','a'};
	try
	{
		CharArrayReader c=new CharArrayReader(ch);
		int i;
		while((i=c.read())!=-1)
		{
	        System.out.print((char)i);
		}
	}
	catch(IOException ie)
	{
		System.out.println("IO Exception");
	}
}
}
