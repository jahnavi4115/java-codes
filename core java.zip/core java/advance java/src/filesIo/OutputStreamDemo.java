package filesIo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class OutputStreamDemo {
	public static void main(String[] args) {
		File f=new File("C:\\Jahnavi IO\\Sample2.txt");
		byte b[]={65,66,67};
		try
		{
			FileOutputStream fo=new FileOutputStream(f);
			fo.write(65);
			fo.write(b);
			fo.write('h');
			System.out.println("Streams Inserted");
			fo.close();
		}
		catch(IOException ie)
		{
			System.out.println("IO Exception");
		}
	}
}
