package filesIo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterDemo {
   public static void main(String[] args) {
	   File f=new File("C:\\Jahnavi IO\\Sample.txt");
	   try
	   {
		   FileWriter fw=new FileWriter(f,true);
		   //fw.write("Data is inserted");
		   fw.write(" Hello");
		   System.out.println("Data is stored");
		   fw.close();
	   }
	   catch(IOException ie)
	   {
		   System.out.println("Exception");
	   }
	   
}
}
