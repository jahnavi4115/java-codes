package filesIo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class InputStreamDemo {
	public static void main(String[] args) {
		File f=new File("C:\\Jahnavi IO\\Sample2.txt");
		try
		{
			int i;
			FileInputStream fo=new FileInputStream(f);
			while((i=fo.read())!=-1)
			{
				System.out.print((char)(i));
			}
			fo.close();
		}
		catch(IOException ie)
		{
			System.out.println("IO Exception");
		}
		
		
	}
}
