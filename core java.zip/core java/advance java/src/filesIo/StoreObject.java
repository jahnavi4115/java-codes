package filesIo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class StoreObject {
  public static void main(String[] args) {
	  File f=new File("C:\\Jahnavi IO\\Sample3.txt");
	  try
	  {
		  FileOutputStream fo=new FileOutputStream(f);
		  ObjectOutputStream o=new ObjectOutputStream(fo);
		  Scholar s=new Scholar(123,"Janu",98);
		  o.writeObject(s);
		  System.out.println("Scholar data saved");
		  o.close();
	  }
	  catch(IOException i)
	  {
		  System.out.println(i);
	  }
	
}
}
