package filesIo;

import java.io.ByteArrayInputStream;

public class ByteArrayInputStreamDemo {
    public static void main(String[] args) {
		byte b[]={'a','b',65,66};
			ByteArrayInputStream ba=new ByteArrayInputStream(b);
			int i;
			while((i=ba.read())!=-1)
			{
		        System.out.print((char)i);
			}	
	}
}
