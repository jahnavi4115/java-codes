package filesIo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyFile {
   public static void main(String[] args) {
	   File f=new File("C:\\Jahnavi IO\\Sample.txt");
	   File f1=new File("C:\\Jahnavi IO\\Sample1.txt");
		try
		{
			FileWriter fw=new FileWriter(f1,true);
			FileReader fr=new FileReader(f);
			int i;
			while((i=fr.read())!=-1)
			{
				   fw.write((char)(i));
			}
			System.out.println("Data copied");
			fr.close();
			fw.close();
		}
		catch(FileNotFoundException fn)
		{
			System.out.println("File not found Exception");
		}
		catch(IOException ie)
		{
			System.out.println("IO Exception");
		}
   }
}
