package collections;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//import java.util.Iterator;
import java.util.ListIterator;

public class collectionDemo {
   public static void main(String[] args) {
   Scanner sc=new Scanner(System.in);
   List<Integer> l=new ArrayList<Integer>();
   /* List<Integer> l1=new ArrayList<Integer>();
      List<Integer> l2=new ArrayList<Integer>();*/
   
   System.out.println("Enter 10 number : ");
   for(int i=0;i<10;i++)
   {
	   int x=sc.nextInt();
	   l.add(x);
   }
   sc.close();
   /*for(Integer ln : l)
   {
	   if(ln%2==0)
		   l1.add(ln);
	   else
		   l2.add(ln);
   }*/
   
   
   /*Iterator<Integer> i=l.iterator();
   while(i.hasNext())
   {
	   Integer x=i.next();
	   System.out.print(x+" ");
   }*/
   ListIterator<Integer> li=l.listIterator();
   while(li.hasNext())
   {
	   Integer x=li.next();
	   System.out.print(x+" ");
   }
   System.out.println();
   while(li.hasPrevious())
   {
	   Integer y=li.previous();
	   System.out.print(y+" ");
   }
}
}
