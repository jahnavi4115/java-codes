package collections;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ListOfEmployees  {
   public static void main(String[] args) 
   {
	List<Employee> l=new ArrayList<Employee>();
	l.add(new Employee(3,25000,"Jahnavi"));
	l.add(new Employee(1,35000,"Jaanu"));
	l.add(new Employee(4,20000,"Dakshayani"));
	l.add(new Employee(2,30000,"Honey"));
	
	Iterator<Employee> i=l.iterator();
	System.out.println(l);
	while(i.hasNext())
	   {
		   Employee e=i.next();
		   System.out.print(e.getEmpId()+"   ");
		   System.out.print(e.getEmpSal()+"   ");
		   System.out.println(e.getEmpName());
	   }
	Collections.sort(l);
	//Collections.sort(l,new NameBased());
	//Collections.sort(l,new IdBased());
	//Collections.sort(l,new SalaryBased());
	
	System.out.println("\nAfter Sorting : ");
	Iterator<Employee> t=l.iterator();
	   while(t.hasNext())
	   {
		   Employee e=t.next();
		   System.out.print(e.getEmpId()+"   ");
		   System.out.print(e.getEmpSal()+"   ");
		   System.out.println(e.getEmpName());
	   }
	
	   
   }
}
