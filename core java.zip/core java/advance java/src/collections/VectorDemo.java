package collections;

import java.util.Vector;
import java.util.Enumeration;

public class VectorDemo {
	public static void main(String[] args) {
		Vector<Integer> v=new Vector<Integer>();
		v.add(123);
		v.add(234);
		v.addElement(23);
		System.out.println(v);
		System.out.println(v.get(2));
		v.removeElement(1);
		System.out.println(v.removeElement(17897));
		System.out.println(v);
		
		Enumeration<Integer> e=v.elements();
		while(e.hasMoreElements())
		{
			System.out.println(e.nextElement());
		}
		v.setSize(3);
		System.out.println(v.size());
	}
}
