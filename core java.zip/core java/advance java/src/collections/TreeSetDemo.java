package collections;

import java.util.TreeSet;
import java.util.Set;

public class TreeSetDemo {
	public static void main(String[] args) {
		TreeSet<Integer> t=new TreeSet<Integer>();
		Set<Integer> s=new TreeSet<Integer>(t);
		s.add(100);
		s.add(101);
		s.add(104);
		s.add(103);
		s.add(100);
		s.add(12);
		System.out.println(s);
	  }
}
