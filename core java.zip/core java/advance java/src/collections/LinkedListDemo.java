package collections;

import java.util.LinkedList;

public class LinkedListDemo {
    public static void main(String[] args) {
		LinkedList<Integer> l=new LinkedList<Integer>();
		l.add(12);
		l.add(23);
		l.add(34);
		l.add(45);
		l.remove(0);
		System.out.println(l.getFirst());
		//l.removeLast();
		System.out.println(l.peek());
		System.out.println(l.pop());
		System.out.println(l);
	}
}
