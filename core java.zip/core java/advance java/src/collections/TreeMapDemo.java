package collections;

import java.util.TreeMap;
import java.util.Map;

public class TreeMapDemo {
	public static void main(String[] args) {
		 Map<Integer,String> m=new TreeMap<Integer,String>();
		 m.put(123,"Jahnavi");
		 m.put(234,"Dakshayani");
		 m.put(123,"Honey");
		 m.put(245, "Jahnavi");
		 m.put(1,"hello");
		 //m.put(null,null);
		 m.put(345,null);
		 System.out.println(m);
		 System.out.println(m.get(234));
		 System.out.println(m.containsValue("hdj"));
		 //System.out.println(m.containsKey(null));
		 System.out.println(m.remove(123));
		 System.out.println(m.keySet());
		 System.out.println(m.values());
		 System.out.println(m);
	   }
}
