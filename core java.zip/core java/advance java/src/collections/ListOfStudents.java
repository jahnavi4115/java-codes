package collections;

import java.util.Set;
import java.util.HashSet;
public class ListOfStudents {
   public static void main(String[] args) {
	Set<Student> s=new HashSet<Student>();
	s.add(new Student(1,"Jahnavi",96));
	s.add(new Student(3,"Honey",95));
	s.add(new Student(1,"Jahnavi",96));
	s.add(new Student(4,"Dakshayani",94));
	for(Student stu : s)
	{
		System.out.print(stu.getStuId()+"  ");
		System.out.print(stu.getStuName()+"  ");
		System.out.println(stu.getMarks());
	}
	
}
}
