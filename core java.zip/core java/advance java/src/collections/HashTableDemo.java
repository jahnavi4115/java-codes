package collections;

import java.util.Hashtable;
import java.util.Map;

public class HashTableDemo {
	public static void main(String[] args) {
		 Map<Integer,String> m=new Hashtable<Integer,String>();
		 m.put(123,"Jahnavi");
		 m.put(234,"Dakshayani");
		 m.put(123,"Honey");
		 m.put(245, "Jahnavi");
		 m.put(1,"hello");
		 //m.put(null,null);
		// m.put(345,null);
		 System.out.println(m);
		 System.out.println(m.get(234));
		 System.out.println(m.containsValue("hdj"));
		 //System.out.println(m.containsKey(null));
		 System.out.println(m.remove(234));
		 System.out.println(m.keySet());
		 System.out.println(m.values());
		 System.out.println(m);
		 
		 for(Map.Entry<Integer,String> ma: m.entrySet())
		 {
			 System.out.println(ma.getKey()+" "+ma.getValue());
		 }
		 
		 for(Integer i : m.keySet())
		 {
			 System.out.println(i);
		 }
		 
		 for(String s : m.values())
		 {
			 System.out.println(s);
		 }
	   }
}
