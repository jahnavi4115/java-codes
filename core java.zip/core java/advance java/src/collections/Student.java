package collections;

public class Student {
  private int stuId;
  public Student(int stuId, String stuName, int marks) {
	super();
	this.stuId = stuId;
	this.stuName = stuName;
	this.marks = marks;
}
private String stuName;
  public int getStuId() {
	return stuId;
}
public void setStuId(int stuId) {
	this.stuId = stuId;
}
public String getStuName() {
	return stuName;
}
public void setStuName(String stuName) {
	this.stuName = stuName;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
private int marks;
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + marks;
	result = prime * result + stuId;
	result = prime * result + ((stuName == null) ? 0 : stuName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Student other = (Student) obj;
	if (marks != other.marks)
		return false;
	if (stuId != other.stuId)
		return false;
	if (stuName == null) {
		if (other.stuName != null)
			return false;
	} else if (!stuName.equals(other.stuName))
		return false;
	return true;
}
}
