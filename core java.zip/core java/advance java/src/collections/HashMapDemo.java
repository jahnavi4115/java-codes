package collections;

import java.util.Map;
import java.util.HashMap;

public class HashMapDemo {
   public static void main(String[] args) {
	 Map<Integer,String> m=new HashMap<Integer,String>();
	 m.put(123,"Jahnavi");
	 m.put(234,"Dakshayani");
	 m.put(null,"Honey");
	 m.put(null,null);
	 m.put(345,null);
	 System.out.println(m);
	 System.out.println(m.get(234));
	 System.out.println(m.containsValue("hdj"));
	 System.out.println(m.containsKey(null));
	 System.out.println(m.remove(234));
	 System.out.println(m.keySet());
	 System.out.println(m.values());
	 System.out.println(m.keySet());
	 System.out.println(m);
	 
	 
	 for(Map.Entry<Integer,String> ma: m.entrySet())
	 {
		 System.out.println(ma.getKey()+" "+ma.getValue());
	 }
   }
}
