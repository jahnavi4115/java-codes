package collections;

import java.util.Set;
import java.util.LinkedHashSet;

public class LinkedHashSetDemo {
  public static void main(String[] args) {
	LinkedHashSet<Integer> l=new LinkedHashSet<Integer>();
	Set<Integer> s=new LinkedHashSet<Integer>(l);
	s.add(100);
	s.add(101);
	s.add(104);
	s.add(104);
	s.add(104);
	s.add(12);
	System.out.println(s);
  }
}