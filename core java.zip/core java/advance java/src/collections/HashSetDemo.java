package collections;

import java.util.Set;
import java.util.HashSet;

public class HashSetDemo {
  public static void main(String[] args) {
	HashSet<Integer> h=new HashSet<Integer>();
	Set<Integer> s=new HashSet<Integer>(h);
	s.add(100);
	s.add(101);
	s.add(104);
	s.add(103);
	s.add(12);
	s.add(12);
	s.add(null);
	s.add(null);
	System.out.println(s);
  }
}
