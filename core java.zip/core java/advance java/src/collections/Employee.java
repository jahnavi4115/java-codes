package collections;

import java.lang.Comparable;

public class Employee implements Comparable<Employee> 
{
  private int empId;
  private float empSal;
  private String empName;
  
   public Employee(int empId, float empSal, String empName) {
	super();
	this.empId = empId;
	this.empSal = empSal;
	this.empName = empName;
  }

  public int getEmpId() {
	return empId;
  }
  public void setEmpId(int empId) {
	this.empId = empId;
  }
  public float getEmpSal() {
	return empSal;
  }
  public void setEmpSal(float empSal) {
	this.empSal = empSal;
  }
  public String getEmpName() {
	return empName;
  }
  public void setEmpName(String empName) {
	this.empName = empName;
  }

  public int compareTo(Employee e)
  {
	  //return this.getId()-e.getId();
	  //return (int)(this.getSal()-e.getSal());
	   return this.getEmpName().compareTo(e.getEmpName());
  }

}
