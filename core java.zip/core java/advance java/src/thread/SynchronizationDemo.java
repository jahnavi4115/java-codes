package thread;

public class SynchronizationDemo {
  public static void main(String[] args) {
	new India("Telangana","Hyderabad");
	new India("Andhra","akv");
	new India("Bihar","Patna");
	new India("Tamilnadu","chennai");
}
}
