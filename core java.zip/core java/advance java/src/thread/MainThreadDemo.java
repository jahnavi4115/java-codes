package thread;

public class MainThreadDemo {
	public static void main(String[] args) {
		ThreadDemo t=new ThreadDemo();
		ThreadDemo t1=new ThreadDemo(4);
		//System.out.println(t1.getState());
		//ThreadDemo1 t1=new ThreadDemo1();
		/*System.out.println(t.isAlive());
	//t.start();
	//t.start();
	//t1.start();
	System.out.println(t.isAlive());
	try
	{
		//t.join();
		Thread.sleep(100);
	}
	catch(InterruptedException ie)
	{
		System.out.println(t.isAlive());
	}
	System.out.println("Main");*/
		System.out.println(Thread.currentThread());
	}
}
