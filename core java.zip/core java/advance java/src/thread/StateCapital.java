package thread;

public class StateCapital {
	synchronized static void print(String state,String capital)
    {
    	System.out.print(state+" ");
    	try
    	{
    		Thread.sleep(1000);
    		System.out.println(capital);
    	}
    	catch(InterruptedException ie)
    	{
    		System.out.println("Thread Interrupted");
    	}
    }
}
