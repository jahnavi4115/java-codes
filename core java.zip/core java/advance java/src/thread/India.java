package thread;

public class India implements Runnable {
  Thread t;
  String state,capital;
  India(String state,String capital)
  {
	  this.state=state;
	  this.capital=capital;
	  t=new Thread(this);
	  t.start();
  }
  public void run()
  {
	  StateCapital.print(state,capital);
  }
}
