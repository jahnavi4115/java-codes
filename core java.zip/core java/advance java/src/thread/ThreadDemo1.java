package thread;

public class ThreadDemo1 extends Thread{
	public void run()
	   {
		   System.out.println("Hello");
	   }

}
