package thread;

public class MainRunnable {
	public static void main(String[] args) {
		 RunnableDemo r=new RunnableDemo();
		 //r.start(); - we get compile time error since in runnable we have only run method 
		  //Thread t=new Thread(r);
		  //t.start();
	}
}
