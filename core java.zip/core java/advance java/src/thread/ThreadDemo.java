package thread;

public class ThreadDemo extends Thread {
	Thread t;
	ThreadDemo()
	{
		t=new Thread(this);
		t.start();
	}
	ThreadDemo(int x)
	{
		Thread t=new Thread();
		t.start();
		System.out.println(x);
	}
   public void run()
   {
	   for(int i=1;i<=10;i++)
	   {
		   System.out.print(i+" ");
		   try
		   {
			   Thread.sleep(100);
		   }
		   catch(InterruptedException ie)
		   {
			  System.out.println(ie.getMessage());
		   }
	   }
   }
}
