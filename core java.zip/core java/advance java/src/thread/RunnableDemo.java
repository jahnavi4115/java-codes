package thread;

public class RunnableDemo implements Runnable {
	Thread t;
	RunnableDemo()
	{
		t=new Thread(this,"Thread Name");
		t.start();
		System.out.println(t.getName());
	}
   public void run()
   {
	   System.out.println("Hello");
   }
}
