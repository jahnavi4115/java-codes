package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class CreateEmployee {
	public static void main(String args[]) throws Exception
	  {                                                  
	    Class.forName("oracle.jdbc.OracleDriver");
	                                                   
	    Connection con = DriverManager.getConnection 
	("jdbc:oracle:thin:@localhost:1521:XE","system","system");
	                                                    
	    Statement stmt = con.createStatement();	
	      
	    stmt.executeUpdate("create table employees(emp_id number, emp_name varchar2(15),emp_sal number(6, 2))"); 
	    stmt.executeUpdate("INSERT INTO employees(EMP_ID,EMP_NAME,EMP_SAL) "+"VALUES (3,'Daksh',6000)");
	    ResultSet rs=stmt.executeQuery("select * from employees");  
		while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3)+" "+rs.getLong(4)+" "+rs.getString(5)+"  "+rs.getString(6)+" "+rs.getString(7)+" "+rs.getDate(8)+" "+rs.getDate(9));  

		con.close();  
	 
	    System.out.println("Table created");
	                                                    
	    stmt.close();
	    con.close();
	  }
}
