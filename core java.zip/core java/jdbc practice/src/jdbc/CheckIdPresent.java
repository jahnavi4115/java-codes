package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CheckIdPresent {
	public static void main(String[] args) {
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		    System.out.println("Connection Established");
		    PreparedStatement ps=con.prepareStatement("select * from employee where emp_id=?");
		    Scanner sc=new Scanner(System.in);
		    System.out.println("Enter employee id : ");
		    int empId=Integer.parseInt(sc.nextLine());
		    sc.close();
		    ps.setInt(1,empId);
		    ResultSet rs=ps.executeQuery();
		    if(rs.next())
		    	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));
		    else
		    	System.out.println("No such Id");
		}
		catch(SQLException s)
		{
			System.out.println(s);
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
	}
}
