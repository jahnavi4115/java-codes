package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class ProcessedStatementDemo {
	public static void main(String args[]) throws Exception
	{

		Class.forName("oracle.jdbc.OracleDriver");

		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");	                                                    
		String sqlquery ="insert into employee values(?,?,?)";
		PreparedStatement pst = con.prepareStatement(sqlquery);
		Scanner sc= new Scanner(System.in);
		while(true)
		{
			System.out.println("enter eno");
			int eid=sc.nextInt();
			System.out.println("enter ename");
			String name=sc.next();
			System.out.println("enter salary");
			int sal=sc.nextInt();
			pst.setInt(1,eid);
			pst.setString(2,name);
			pst.setInt(3,sal);
			pst.executeUpdate();
			System.out.println("inserted");
			System.out.println("need more record[yes/no]:");
			String option=sc.next();
			if (option.equalsIgnoreCase("no"))
			{
				break;
			}
		}
		con.close();
	}
}

