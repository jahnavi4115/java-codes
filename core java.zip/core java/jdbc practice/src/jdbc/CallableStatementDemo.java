package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;

public class CallableStatementDemo {
	public static void main(String args[]) throws Exception
	{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		CallableStatement cst = con.prepareCall("{call pro(?,?,?)}");
		cst.setInt(1,200);
		cst.setInt(2,300);
		cst.registerOutParameter(3,Types.INTEGER);
		cst.execute();
		System.out.println( cst.getInt(3));
		cst.close();                                               
		con.close();
	}
}
