package jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class RegisterEmployee {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
			System.out.println("Connection Established");
			/*PreparedStatement ps1=con.prepareStatement("create table employeess(emp_id number, emp_name varchar2(15),emp_sal number(6, 2))");
		    ps1.executeUpdate();*/
			PreparedStatement ps=con.prepareStatement("insert into emp values(?,?,?,?,?,?,?,?,?)");
			System.out.print("Enter id : ");
			int empId=Integer.parseInt(sc.nextLine());
			System.out.print("Enter name : ");
			String empName=sc.nextLine();
			System.out.print("Enter salary : ");
			int empSal=Integer.parseInt(sc.nextLine());
			System.out.print("Enter mobile number : ");
			long empNumber=Long.parseLong(sc.nextLine());
			System.out.print("Enter your email id : ");
			String empEmail=sc.nextLine();
			System.out.print("Enter your Gender : ");
			String empGender=sc.nextLine();
			System.out.print("Enter your address : ");
			String empAddress=sc.nextLine();
			System.out.print("Enter your date of joining : ");
			String date1=sc.nextLine();
			SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date jd=sdf.parse(date1);
			java.sql.Date empDoj=new Date(jd.getTime());
			System.out.print("Enter your date of birth : ");
			String date2=sc.nextLine();
			java.util.Date jd1=sdf.parse(date2);
			java.sql.Date empDob=new Date(jd1.getTime());
			ps.setInt(1,empId);
			ps.setString(2,empName);
			ps.setInt(3,empSal);
			ps.setLong(4,empNumber);
			ps.setString(5,empEmail);
			ps.setString(6,empGender);
			ps.setString(7,empAddress);
			ps.setDate(8,empDoj);
			ps.setDate(9,empDob);
			int result=ps.executeUpdate();
			if(result>0)
			{
				System.out.println("Employee details inserted successfully");
				con.commit();
			}
		}
		catch(ParseException p)
		{
			System.out.println(p);
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
		catch(SQLException s)
		{
			System.out.println(s);
		}
	}
}
