package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertValues {
	 public static void main(String args[]) throws Exception
	  {                                                 
	    Class.forName("oracle.jdbc.OracleDriver");
	                                                  
	    Connection con = DriverManager.getConnection
	("jdbc:oracle:thin:@localhost:1521:XE","system","system");
	                                                    
	    Statement stmt = con.createStatement();
	                                                    
	     stmt.executeUpdate("INSERT INTO employee(EMP_ID,EMP_NAME,EMP_SAL) "+"VALUES (3,'Daksh',6000)");

	    System.out.println("data inserted");
	                                                   
	    stmt.close();
	    con.close();
	  }
}
