package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteEmployee {
	public static void main(String[] args) {
		  Scanner sc=new Scanner(System.in);
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		    System.out.println("Connection Established");
		    PreparedStatement ps=con.prepareStatement("delete from emp where name=?");
		    System.out.print("Enter Employee name ");
		    String empName=sc.nextLine();
		    ps.setString(1,empName);
		    int result=ps.executeUpdate();
		    if(result>0)
		    {
		    	System.out.println("Employee details deleted successfully");
		    	con.commit();
		    }
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
		catch(SQLException s)
		{
			System.out.println(s);
		}
}
}
