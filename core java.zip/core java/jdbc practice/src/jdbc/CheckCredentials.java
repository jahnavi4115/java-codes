package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CheckCredentials {
	public static void main(String[] args) {
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		    System.out.println("Connection Established");
		    PreparedStatement ps=con.prepareStatement("select * from employee where emp_id=? and emp_name=?");
		    Scanner sc=new Scanner(System.in);
		    System.out.println("Enter employee id : ");
		    int empId=Integer.parseInt(sc.nextLine());
		    System.out.print("Enter employee name : ");
		    String empName=sc.nextLine();
		    sc.close();
		    ps.setInt(1,empId);
		    ps.setString(2,empName);
		    ResultSet rs=ps.executeQuery();
		    if(rs.next())
		    	System.out.println("Credentials exists");
		    else
		    	System.out.println("No such credentails");
		}
		catch(SQLException s)
		{
			System.out.println(s);
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
	}
}
