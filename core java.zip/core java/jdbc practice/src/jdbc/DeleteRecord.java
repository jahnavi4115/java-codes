package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DeleteRecord {
	public static void main(String args[]) throws Exception
	  {                                                 
	    Class.forName("oracle.jdbc.OracleDriver");
	                                                  
	    Connection con = DriverManager.getConnection
	("jdbc:oracle:thin:@localhost:1521:XE","system","system");
	                                                    
	    Statement stmt = con.createStatement();
	                                                    
	     stmt.executeUpdate("delete employee where emp_id=1");

	    System.out.println("data deleted");
	                                                   
	    stmt.close();
	    con.close();
	  }
}
