package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class DbTest {
  public static void main(String[] args) {
	try
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Driver Loaded");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
	    System.out.println("Connection Established");
	}
	catch(ClassNotFoundException c)
	{
		System.out.println(c);
	}
	catch(SQLException s)
	{
		System.out.println(s);
	}
}
}
