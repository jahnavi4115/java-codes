package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateEmployee {
	public static void main(String[] args) {
		  Scanner sc=new Scanner(System.in);
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver Loaded");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
		    System.out.println("Connection Established");
		    PreparedStatement ps=con.prepareStatement("update emp set name=? where id=?");
		    System.out.print("Enter employee id to which the name need to be updated : ");
		    int empId=Integer.parseInt(sc.nextLine());
		    System.out.print("Enter Name to be updated : ");
		    String empName=sc.nextLine();
		    sc.close();
		    ps.setString(1,empName);
		    ps.setInt(2,empId);
		    int result=ps.executeUpdate();
		    if(result>0)
		    {
		    	System.out.println("Employee details updated successfully");
		    	con.commit();
		    }
		    else
		    {
		    	System.out.println("Please enter valid id");
		    }
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
		}
		catch(SQLException s)
		{
			System.out.println(s);
		}
}
}
