package com.springmvc.dao;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

import com.springmvc.model.AuthenticEmployee;
import com.springmvc.model.Employee;

public class EmployeeDAOTest {

	EmployeeDAO employeeDAO;
	Employee employee;
	public EmployeeDAOTest() {
		employeeDAO=new EmployeeDAO();
	}
	@Test
	public void testAddEmployee() {
		//fail("Not yet implemented");
		assertNotEquals(0,employeeDAO.addEmployee(new Employee("Jahn56433","Jahnavi", "10000","9876543210","janu@gmail.com",
				"female","guntur",new Date(),"jahnavi@123")));
		
	}

	@Test
	public void testUpdateRecord() {
		//fail("Not yet implemented");
		employee=new Employee();
		employee.setUserName("Jahn56433");
		employee.setMobileNumber("9876543210");
		assertTrue(employeeDAO.updateRecord(employee));
	}

	@Test
	public void testDeleteRecord() {
		//fail("Not yet implemented");
		assertTrue(employeeDAO.deleteRecord("Jahn56433"));
	}

	@Test
	public void testDisplayWithId() {
		//fail("Not yet implemented");
		assertNotNull(employeeDAO.displayWithId("Jahn56433"));
	}

	@Test
	public void testDisplayAll() {
		//fail("Not yet implemented");
		assertEquals(1,employeeDAO.displayAll().size());
	}

	@Test
	public void testAuthentication() {
		//fail("Not yet implemented");
		AuthenticEmployee employee=new AuthenticEmployee();
		employee.setUserName("Jahn56433");
		employee.setPassword("jahnavi@123");
		assertNotNull(employeeDAO.authentication(employee));
	}

}
