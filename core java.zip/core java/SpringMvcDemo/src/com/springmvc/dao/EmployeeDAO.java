package com.springmvc.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc.model.AuthenticEmployee;
import com.springmvc.model.Employee;

@Repository//("employeeDAO")
public class EmployeeDAO {
	@Autowired
	SessionFactory sessionFactory;
	Query query;
	Session session;
	Employee employeeVo;
	String result;
	boolean check;
	String name;
	@Transactional
	public String addEmployee(Employee employee)
	{
		session=sessionFactory.getCurrentSession();
		result= (String)session.save(employee);
		return result;
	}
	@Transactional
	public boolean updateRecord(Employee employee) 
	{
		session=sessionFactory.getCurrentSession();
		employeeVo=(Employee) session.get(Employee.class,employee.getUserName());
		if(employeeVo!=null)
		{
			check=true;
			employeeVo.setMobileNumber(employee.getMobileNumber());
		}
		return check;
	}
	@Transactional
	public boolean deleteRecord(String userName) 
	{
		session=sessionFactory.getCurrentSession();
		employeeVo=(Employee) session.get(Employee.class,userName);
		if(employeeVo!=null)
		{
			session.delete(employeeVo);
			check=true;
		}
		return check;
	}
	@Transactional
	public Employee displayWithId(String userName)
	{
		session=sessionFactory.getCurrentSession();
		employeeVo=(Employee) session.get(Employee.class,userName);
		return employeeVo;
	}
	@Transactional
	public List<Employee> displayAll()
	{
		return sessionFactory.getCurrentSession().createQuery("from Employee").list();
	}
	@Transactional
	public String authentication(AuthenticEmployee employee)
	{
		session=sessionFactory.getCurrentSession();
		query=session.createQuery("from Employee where userName=:userName and password=:password");	
		query.setParameter("userName",employee.getUserName());
		query.setParameter("password",employee.getPassword());
		employeeVo=(Employee) query.uniqueResult(); 
		if(employeeVo!=null)
		{
			name=employeeVo.getEmpName();
		}
		return name;
	}
}


