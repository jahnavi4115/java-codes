package com.springmvc.controller;

import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.dao.EmployeeDAO;
import com.springmvc.model.AuthenticEmployee;
import com.springmvc.model.Employee;

@Controller
public class EmployeeController { 
	@Autowired
	EmployeeDAO employeeDAO;
	ModelAndView modelAndView;
	Employee employee;
	List<Employee> listOfEmployees;
	String name;
	String userName;
	boolean check;
	String result;

	@RequestMapping("/Index")
	public String display(Model m)
	{
		m.addAttribute("emp",new AuthenticEmployee());
		return "Login";
	}

	@RequestMapping("/validate")
	public String validate(Model m)
	{
		m.addAttribute("emp", new Employee());
		return "Registration";
	}

	/*@RequestMapping("/Validate")
	public String validatePage(Model m)
	{
		m.addAttribute("emp", new Employee());
		return "ValidateForm";
	}

	@RequestMapping("/validatePage")  
	public String submitForm( @Valid @ModelAttribute("emp") Employee e, BindingResult br)  
	{  
		if(br.hasErrors())  
		{  
			return "ValidateForm";  
		}  
		else  
		{  
			return "Final";  
		}  
	}*/

	@RequestMapping("/Registration")
	public String registrationPage()
	{
		return "Registration";
	}

	@RequestMapping("/Update")
	public String updatePage(Model m)
	{
		m.addAttribute("emp",new Employee());
		return "UpdateEmp";
	}

	@RequestMapping(value="/registrate" ,method=RequestMethod.POST)
	public String addEmployee(@Valid @ModelAttribute("emp") Employee employee, BindingResult br,Model m)
	{
		if(br.hasErrors())  
		{  
			//modelAndView=new ModelAndView("Registration","emp",new Employee());
			result="Registration";
		}  
		else  
		{  
			userName=employee.getEmpName().substring(0,4)+new Random().nextInt(100000);
			employee.setUserName(userName);
			result=employeeDAO.addEmployee(employee);
			if(result!=null)
				//modelAndView=new ModelAndView("Login","key","Registered Successfully and Your User Name : "+userName);
				m.addAttribute("key","Registered Successfully and Your User Name : "+userName);
			result="Login";
		}
		return result;
	} 

	@RequestMapping(value="/updateMobile" ,method=RequestMethod.POST)
	public String update(@ModelAttribute("emp") Employee employee,HttpSession session,BindingResult br,Model m)
	{
		if(br.hasErrors())  
		{  
			result="UpdateEmp";
		}  
		else
		{
			employee.setUserName((String)session.getAttribute("idKey"));
			check=employeeDAO.updateRecord(employee);
			if(check)
			{
				//modelAndView=new ModelAndView("Home","key","Updated Successfully");
				m.addAttribute("key","Updated Successfully");
				result="Home";
			}
		}
		return result;
	}

	@RequestMapping(value="/Delete")
	public ModelAndView delete(HttpSession session)
	{
		check=employeeDAO.deleteRecord((String)session.getAttribute("idKey"));
		return new ModelAndView("Login","key","deleted");
	}

	@RequestMapping(value="/authentic" ,method=RequestMethod.POST)
	public String authenticate(@Valid @ModelAttribute("emp") AuthenticEmployee employee,HttpSession session,BindingResult br,Model model)
	{    	
		if(br.hasErrors())  
		{  
			result="Login";
		}  
		else
		{
			name=((EmployeeDAO) employeeDAO).authentication(employee);
			if(name!=null)
			{
				session.setAttribute("idKey",employee.getUserName());
				//modelAndView=new ModelAndView("Home","key","Welcome "+name);
				model.addAttribute("key","Welcome "+name);
				result="Home";
			}
			else
			{
				//modelAndView=new ModelAndView("Login","key","Invalid credentials");
				model.addAttribute("key","Invalid credentials");
				result="Login";
			}
		}
		return result;
	}

	@RequestMapping(value="/Display")
	public ModelAndView display(HttpSession session)
	{
		employee=employeeDAO.displayWithId((String) session.getAttribute("idKey"));
		return new ModelAndView("DisplayEmployee","empKey",employee);
	}

	@RequestMapping(value="/DisplayAll")
	public ModelAndView displayAll()
	{
		listOfEmployees=employeeDAO.displayAll();
		if(!listOfEmployees.isEmpty())
			modelAndView=new ModelAndView("DisplayAllEmployees","listKey",listOfEmployees);
		else
			modelAndView=new ModelAndView("Home","key","No data found");
		return modelAndView;
	}
}