package com.springmvc.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="employees")
public class Employee {
	@Id
	private String userName;
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(String userName, String empName, String empSalary, String mobileNumber, String emailId,
			String gender, String empAddress, Date dob, String password) {
		super();
		this.userName = userName;
		this.empName = empName;
		this.empSalary = empSalary;
		this.mobileNumber = mobileNumber;
		this.emailId = emailId;
		this.gender = gender;
		this.empAddress = empAddress;
		this.dob = dob;
		this.password = password;
	}
	@Size(min=4,message="Name must contain morethan 4 letters")
	private String empName;
	@NotEmpty
	private String empSalary;
	@Pattern(regexp="^[6789]{1}[0-9]{9}",message="Please enter a valid mobile number")
	private String mobileNumber;
	@NotEmpty(message="Please enter valid email id")
	private String emailId;
	@NotEmpty(message="Please select gender")
	private String gender;
	@NotEmpty(message="Address can't be empty")
	private String empAddress;
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	//@NotEmpty(message="Please select the date")
	private Date dob;
	@Size(min=5,message="Password must be greater than 5 character")
	private String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
