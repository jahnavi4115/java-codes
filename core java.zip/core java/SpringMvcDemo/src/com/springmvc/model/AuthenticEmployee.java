package com.springmvc.model;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class AuthenticEmployee {
	@NotEmpty(message="required")
	private String userName;
	@Size(min=5,message="Password must be greater than 5 character")
	private String password;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
