package com.university;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@NamedQueries(

		  { 
			@NamedQuery(
					name="displayAll",
					query="from Student"
					)	,
			@NamedQuery(
					name="displayStudent",
					query="from Student where name=:name"
					)	
		  }
		)
@Entity
@Table(name="students")
public class Student {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	private int marks;
	@Column(name="mobile_number")
	private long mobileNumber;
	@Column(name="email_id")
	private String emailId;
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn
	private University university;
	public University getUniversity() {
		return university;
	}
	public void setUniversity(University university) {
		this.university = university;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
