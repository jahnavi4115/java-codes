package com.university;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.school.util.DbUtil;

public class ManyToOneDisplay {
	public static void main(String[] args) {
		DbUtil dbUtil=new DbUtil();
		Session session=dbUtil.getMySession();
		//Query query=session.getNamedQuery("displayAll");
		Query query=session.getNamedQuery("displayStudent");
		query.setString("name","Jahnavi");
		List<Student> list=query.list();
		for(Student student:list)
			System.out.println(student.getId()+" "+student.getName()+" "+student.getMarks()+" "+student.getEmailId()+" "+student.getMobileNumber()+" "+student.getUniversity().getUniversityId()+" "+student.getUniversity().getUniversityName()+" "+student.getUniversity().getUniversityLocation());
	}
}
