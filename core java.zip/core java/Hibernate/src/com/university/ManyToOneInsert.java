package com.university;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.school.util.DbUtil;

public class ManyToOneInsert {
	public static void main(String[] args) {
		DbUtil dbUtil=new DbUtil();
		Session session=dbUtil.getMySession();
		Transaction transaction=session.beginTransaction();
		University university=new University();
		university.setUniversityName("Vishnu");
		university.setUniversityLocation("Bhimavaram");
		Student student1=new Student();
		student1.setName("Jahnavi");
		student1.setMarks(80);
		student1.setMobileNumber(9877655432l);
		student1.setEmailId("janu@gmail.com");
		student1.setUniversity(university);
		Student student2=new Student();
		student2.setName("Dakshayni");
		student2.setMarks(90);
		student2.setMobileNumber(9877345632l);
		student2.setEmailId("daksha@gmail.com");
		student2.setUniversity(university);
		Student student3=new Student();
		student3.setName("Haneesha");
		student3.setMarks(70);
		student3.setMobileNumber(9812345632l);
		student3.setEmailId("honey@gmail.com");
		student3.setUniversity(university);
		session.save(student1);
		session.save(student2);
		session.save(student3);
		transaction.commit();
	}
}
