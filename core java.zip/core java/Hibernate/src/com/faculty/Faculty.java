package com.faculty;



import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="faculty")
public class Faculty {
	@Id
	@GeneratedValue
	@Column(name="faculty_id")
	private int facultyId;
	@Column(name="faculty_name")
	private String facultyName;
	@Column(name="faculty_sal")
	private float facultySalary;
	@Temporal(TemporalType.DATE)
	@Column(name="date_of_joining")
	private Date dateOfJoining;
	@Column(name="mobile_number")
	private long mobileNumber;
	@Column(name="email_id")
	private String emailId;
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn
	private List<Address> listOfAddress;
	
	public List<Address> getListOfAddress() {
		return listOfAddress;
	}
	public void setListOfAddress(List<Address> listOfAddress) {
		this.listOfAddress = listOfAddress;
	}
	/*@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn//(name="address_id")
	private Address address;
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}*/
	public int getFacultyId() {
		return facultyId;
	}
	public void setFacultyId(int facultyId) {
		this.facultyId = facultyId;
	}
	public String getFacultyName() {
		return facultyName;
	}
	public void setFacultyName(String facultyName) {
		this.facultyName = facultyName;
	}
	public float getFacultySalary() {
		return facultySalary;
	}
	public void setFacultySalary(float facultySalary) {
		this.facultySalary = facultySalary;
	}
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}