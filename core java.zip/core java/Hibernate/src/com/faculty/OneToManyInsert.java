package com.faculty;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.school.util.DbUtil;

public class OneToManyInsert {
	public static void main(String[] args) {
		DbUtil dbUtil=new DbUtil();
        Session session = dbUtil.getMySession();
        Transaction transaction=session.beginTransaction();
        Address address1= new Address();
        address1.setPincode(530028);
        address1.setState("ap");
        address1.setStreetName("lakshmi puram");
        Address address2=new Address();
        address2.setPincode(6544555);
        address2.setState("telangana");
        address2.setStreetName("amirpet");
        List<Address> list=new ArrayList<Address>();
        list.add(address1);
        list.add(address2);
        Faculty faculty= new Faculty();
        faculty.setFacultyId(1);
        faculty.setFacultyName("cs");
        faculty.setFacultySalary(85000);
        faculty.setEmailId("csr@gmail.com");
        faculty.setDateOfJoining(new Date());
        faculty.setMobileNumber(9876543210l);
        faculty.setListOfAddress(list);
        session.save(faculty);
        transaction.commit();
	}
}
