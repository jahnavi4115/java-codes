package com.faculty;

import java.util.Date;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.school.util.DbUtil;

public class FacultyToAddress {
	public static void main(String[] args) {
		try{
			DbUtil dbUtil=new DbUtil();
			Session session=dbUtil.getMySession();
			Transaction transaction=session.beginTransaction();
			Scanner sc=new Scanner(System.in);
			//System.out.println("Enter id : ");
			//int id=Integer.parseInt(sc.nextLine());
			System.out.println("Enter name : ");
			String name=sc.nextLine();
			System.out.println("Enter salary : ");
			float salary=Float.parseFloat(sc.nextLine());
			System.out.println("Enter email : ");
			String email=sc.nextLine();
			System.out.println("Enter mobile number : ");
			long number=Long.parseLong(sc.nextLine());
			//System.out.println("Enter door number : ");
			//int doorNo=Integer.parseInt(sc.nextLine());
			System.out.println("Enter street name : ");
			String streetName=sc.nextLine();
			System.out.println("Enter state : ");
			String state=sc.nextLine();
			System.out.println("Enter pincode : ");
			int pincode=Integer.parseInt(sc.nextLine());
			Address address=new Address();
			sc.close();
			Faculty faculty=new Faculty();
			//faculty.setFacultyId(id);
			faculty.setFacultyName(name);
			faculty.setFacultySalary(salary);
			faculty.setDateOfJoining(new Date());
			faculty.setMobileNumber(number);
			faculty.setEmailId(email);
			//address.setDoorNo(doorNo);
			address.setState(state);
			address.setPincode(pincode);
			address.setStreetName(streetName);
			//faculty.setAddress(address);
			//session.save(address);
			session.save(faculty);
			transaction.commit();
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
}
