package com.faculty;

import org.hibernate.Session;

import com.school.util.DbUtil;

public class OneToOneDisplay {
	public static void main(String[] args) {
		DbUtil dbUtil=new DbUtil();
		Session session=dbUtil.getMySession();
        Faculty faculty=session.get(Faculty.class,1);
        if(faculty!=null)
		{
			System.out.println(faculty.getFacultyName()+" "+faculty.getFacultySalary()+" "+faculty.getEmailId()+" "+faculty.getMobileNumber()+" "+faculty.getDateOfJoining());
			//Address address=faculty.getAddress();
			//System.out.println(address.getDoorNo()+" "+address.getState()+" "+address.getStreetName()+" "+address.getPincode());
			
		}
        else
        {
        	System.out.println("Invalid ID");
        }
	}
}
