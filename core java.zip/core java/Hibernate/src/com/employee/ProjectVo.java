package com.employee;

 

import java.util.ArrayList;
import java.util.List;

 

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

 

@Entity
@Table(name="project")

 

public class ProjectVo {
    @Id
    @GeneratedValue 
    private int projectId;
    public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public List<EmployeeVo> getEmployees() {
		return employees;
	}
	public void setEmployees(List<EmployeeVo> employees) {
		this.employees = employees;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	@ManyToMany(mappedBy="projects")
    private List<EmployeeVo> employees = new ArrayList<EmployeeVo>();
    private String projectName;
    
    

 

}
 