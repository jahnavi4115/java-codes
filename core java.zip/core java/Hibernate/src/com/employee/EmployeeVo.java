package com.employee;

import java.util.ArrayList;
import java.util.List;

 

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="employee")

public class EmployeeVo {

     public List<ProjectVo> getProjects() {
		return projects;
	}
	public void setProjects(List<ProjectVo> projects) {
		this.projects = projects;
	}
	public int getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	@ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "Employee_Project", 
        joinColumns = { @JoinColumn(name = "Employee_ID") }, 
        inverseJoinColumns = { @JoinColumn(name = "Project_ID") })
    private List<ProjectVo> projects = new ArrayList<ProjectVo>();
    
    @Id
    @GeneratedValue
    private int EmployeeId;
    private String EmployeeName;
    private int salary;
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
}