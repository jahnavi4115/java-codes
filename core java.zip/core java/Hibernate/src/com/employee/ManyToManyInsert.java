package com.employee;

import org.hibernate.Session;

import com.school.util.DbUtil;

public class ManyToManyInsert {
	public static void main(String[] args) {

		EmployeeVo employee1 = new EmployeeVo();
		employee1.setEmployeeName("Jahnavi");
		employee1.setSalary(50000);
		EmployeeVo employee2 = new EmployeeVo();
		employee2.setEmployeeName("Nithya");
		employee2.setSalary(45000);

		ProjectVo project1 = new ProjectVo();
		project1.setProjectName("Indulz");

		ProjectVo project2=new ProjectVo();
		project2.setProjectName("Medical store");

		ProjectVo project3=new ProjectVo();
		project3.setProjectName("Happy Tours");

		employee1.getProjects().add(project1);
		employee1.getProjects().add(project2);
		employee1.getProjects().add(project3);

		employee2.getProjects().add(project1);
		employee2.getProjects().add(project2);

		DbUtil db=new DbUtil();
		Session session=db.getMySession();
		session.beginTransaction();

		session.persist(employee1);
		session.persist(employee2);

		session.getTransaction().commit();
		session.close();  
	}

}