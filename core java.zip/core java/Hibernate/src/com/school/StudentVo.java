package com.school;

/*import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;*/

/*@NamedQueries(

		  { 
			@NamedQuery(
					name="displayAll",
					query="from StudentVo"
					)	
		  }
		)*/
public class StudentVo {
	private int id;
	private String name;
	private int marks;
	private long mobileNumber;
	private String emailId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
