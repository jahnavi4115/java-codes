package com.school;

import java.util.Scanner;

import com.school.dao.StudentDAOImpl;

public class DeleteStudentRecord {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id : ");
		int id=Integer.parseInt(sc.nextLine());
		StudentDAOImpl studentDAO=new StudentDAOImpl();
		boolean result=studentDAO.deleteRecord(id);
		if(result)
		{
			System.out.println("Deleted..");
		}
		else
		{
			System.out.println("Invalid ID");
		}
		sc.close();
	}
}
