package com.school.util;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DbUtil {
	SessionFactory sessionFactory;
	Session session;
	{
		try
		{
			Configuration configuration=new Configuration();
			sessionFactory=configuration.configure().buildSessionFactory();
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
	public Session getMySession()
	{
		try
		{
			session=sessionFactory.openSession();
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return session;
	}
	public void closeSession(Session session)
	{
		try
		{
			if(sessionFactory!=null)
			{
				sessionFactory.close();
			}
			if(session!=null)
			{
				session.close();
			}
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
}
