package com.school;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class LoadDemo {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id : ");
		int id=Integer.parseInt(sc.nextLine());
		try{
			Configuration cn=new Configuration();
			SessionFactory sf=cn.configure().buildSessionFactory();
			Session s=sf.openSession();
			StudentVo student=s.load(StudentVo.class,id);
			if(student!=null)
			{
			System.out.println("Id  : "+student.getId());
			System.out.println("Name : "+student.getName());
			System.out.println("Marks : "+student.getMarks());
			System.out.println("Email Id : "+student.getEmailId());
			System.out.println("Mobile Number : "+student.getMobileNumber());
			}
			else
			{
				System.out.println("Invalid ID");
			}
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		sc.close();
	}
}
