package com.school.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.school.StudentVo;
import com.school.util.DbUtil;

public class StudentDAOImpl implements StudentDAOIface{
	DbUtil dbUtil;
	Session session;
	StudentVo studentVo;
	Transaction transaction;
	boolean check;
	Query query;
	List<StudentVo> listOfStudents;
	Criteria criteria;
	Iterator<StudentVo> iterator;
	int result;
	{
		try{
			dbUtil=new DbUtil();
			session=dbUtil.getMySession();
			transaction=session.beginTransaction();
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
	public int addStudent(StudentVo studentVo)
	{
		try
		{
			result=(int) session.save(studentVo);
			if(result>0)
			{
				transaction.commit();
				dbUtil.closeSession(session);
			}
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return result;
	}
	public boolean updateRecord(StudentVo student) 
	{
		try
		{
			studentVo=session.get(StudentVo.class,student.getId());
			if(studentVo!=null)
			{
				check=true;
				studentVo.setMarks(student.getMarks());
				studentVo.setEmailId(student.getEmailId());
				studentVo.setMobileNumber(student.getMobileNumber());
				transaction.commit();
				dbUtil.closeSession(session);
			}
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return check; 

	}
	public boolean deleteRecord(int id) {
		try
		{

			studentVo=session.get(StudentVo.class,id);
			if(studentVo!=null)
			{
				check=true;
				session.delete(studentVo);
				transaction.commit();
				dbUtil.closeSession(session);
			}
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return check;
	}
	public List<StudentVo> displayAll()
	{
		try
		{
			query=session.getNamedQuery(DISPLAY_ALL);
			listOfStudents=query.list();
			dbUtil.closeSession(session);
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return listOfStudents;
	}
	public List<StudentVo> displayAllCriteria()
	{
		try
		{
			criteria=session.createCriteria(StudentVo.class);
			listOfStudents=criteria.list();
			dbUtil.closeSession(session);
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return listOfStudents;
	}
	public StudentVo displayWithId(int studentId)
	{
		try
		{
			studentVo=session.get(StudentVo.class,studentId);
			dbUtil.closeSession(session);
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return studentVo;
	}
	public StudentVo displayWithMobile(long mobileNumber)
	{
		try
		{
			query=session.createQuery(DISPLAY_WITH_MOBILE);
			query.setParameter("mobile",mobileNumber);
			studentVo=(StudentVo)query.uniqueResult(); 
			dbUtil.closeSession(session);
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		return studentVo;
	}
	public List<StudentVo> like(char letter)
	{
		criteria=session.createCriteria(StudentVo.class);
		criteria.add(Restrictions.like("name",letter+"%"));
	    List<StudentVo> listOfStudents=criteria.list();
	    return listOfStudents;
	}
	public List<StudentVo> between(int min,int max)
	{
		criteria=session.createCriteria(StudentVo.class);
		criteria.add(Restrictions.between("marks",min,max));
	    listOfStudents=criteria.list();
	    return listOfStudents;
	}
}
