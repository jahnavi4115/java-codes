package com.school.dao;

import java.util.List;

import com.school.StudentVo;

public interface StudentDAOIface {
	int addStudent(StudentVo studentVo);
	boolean updateRecord(StudentVo student);
	boolean deleteRecord(int id);
	List<StudentVo> displayAll();
	StudentVo displayWithId(int studentId);
	StudentVo displayWithMobile(long mobileNumber);
	String DISPLAY_ALL="from StudentVo";
	String DISPLAY_WITH_MOBILE="from StudentVo where mobileNumber=:mobile";
}
