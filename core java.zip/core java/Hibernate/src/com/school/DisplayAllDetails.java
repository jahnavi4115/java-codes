package com.school;

import java.util.Iterator;
import java.util.List;

import com.school.dao.StudentDAOImpl;

public class DisplayAllDetails {
	public static void main(String[] args) {
		StudentDAOImpl studentDAO=new StudentDAOImpl();
		List<StudentVo> listOfStudents=studentDAO.displayAll();
		if(!listOfStudents.isEmpty())
		{
			Iterator iterator=listOfStudents.iterator();
			System.out.println("Id  Name  Marks     Email       Mobile Number");
			System.out.println("--  ----  -----     -----       -------------");
			while(iterator.hasNext())
			{
				StudentVo student=(StudentVo) iterator.next();
				System.out.print(student.getId()+" ");
				System.out.print(student.getName()+" ");
				System.out.print(student.getMarks()+" ");
				System.out.print(student.getEmailId()+" ");
				System.out.println(student.getMobileNumber()+" ");
			}
		}
		else
		{
			System.out.println("No data Found");
		}
	}
}
