package com.school;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateWithoutChecking {
	public static void main(String[] args) {
		try
		{
			Configuration cn=new Configuration();
			SessionFactory sf=cn.configure().buildSessionFactory();
			Session s=sf.openSession();
			Transaction t=s.beginTransaction();
			StudentVo student=new StudentVo();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter id : ");
			int id=Integer.parseInt(sc.nextLine());
			System.out.println("Enter name : ");
			String name=sc.nextLine();
			System.out.println("Enter marks : ");
			int marks=Integer.parseInt(sc.nextLine());
			System.out.println("Enter email : ");
			String email=sc.nextLine();
			System.out.println("Enter mobile number : ");
			long number=Long.parseLong(sc.nextLine());
			sc.close();
			student.setId(id);
			student.setName(name);
			student.setMarks(marks);
			student.setEmailId(email);
			student.setMobileNumber(number);
			s.update(student);
			t.commit();
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
}
