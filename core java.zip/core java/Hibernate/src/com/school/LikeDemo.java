package com.school;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.school.dao.StudentDAOImpl;
import com.school.util.DbUtil;

public class LikeDemo {
	public static void main(String[] args) {
		try
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter letter : ");
			char letter=sc.next().charAt(0);
			StudentDAOImpl studentDAOImpl=new StudentDAOImpl();
			List<StudentVo> listOfStudents=studentDAOImpl.like(letter);			
			if(!listOfStudents.isEmpty())
			{
				Iterator iterator=listOfStudents.iterator();
				System.out.println("Id  Name  Marks     Email       Mobile Number");
				System.out.println("--  ----  -----     -----       -------------");
				while(iterator.hasNext())
				{
					StudentVo student=(StudentVo) iterator.next();
					System.out.print(student.getId()+" ");
					System.out.print(student.getName()+" ");
					System.out.print(student.getMarks()+" ");
					System.out.print(student.getEmailId()+" ");
					System.out.println(student.getMobileNumber()+" ");
				}
			}
			else
			{
				System.out.println("Data not found");
			}

		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
}
