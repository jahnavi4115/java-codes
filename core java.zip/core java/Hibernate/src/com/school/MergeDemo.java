package com.school;
import java.util.Scanner;

 

 

 

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.school.util.DbUtil;

 


public class MergeDemo {

 

 

    public static void main(String[] args) 
    {
        DbUtil dbUtil = new DbUtil();
        Session session = dbUtil.getMySession();
        StudentVo student=session.get(StudentVo.class,1);
        Scanner sc=new Scanner(System.in);
		System.out.println("Enter name : ");
		String name=sc.nextLine();
		System.out.println("Enter marks : ");
		int marks=Integer.parseInt(sc.nextLine());
		System.out.println("Enter email : ");
		String email=sc.nextLine();
		System.out.println("Enter mobile number : ");
		long number=Long.parseLong(sc.nextLine());
		sc.close();
		student.setName(name);
		student.setMarks(marks);
		student.setEmailId(email);
		student.setMobileNumber(number);
        Session session1 = dbUtil.getMySession();
        session1.get(StudentVo.class,1);
        Transaction transaction1 = session1.beginTransaction();
        session1.merge(student);
        sc.close();
        transaction1.commit();
    }
}

 