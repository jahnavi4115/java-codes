package com.school;

import java.util.Scanner;

import com.school.dao.StudentDAOImpl;

public class DisplayWithMobile {
	public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Mobile Number : ");
			Long mobileNumber=Long.parseLong(sc.nextLine());
			StudentDAOImpl studentDAO=new StudentDAOImpl();
			StudentVo studentVo=studentDAO.displayWithMobile(mobileNumber);
			sc.close();
			if(studentVo!=null)
			{
			System.out.println("Id  : "+studentVo.getId());
			System.out.println("Name : "+studentVo.getName());
			System.out.println("Marks : "+studentVo.getMarks());
			System.out.println("Email Id : "+studentVo.getEmailId());
			System.out.println("Mobile Number : "+studentVo.getMobileNumber());
			}
			else
			{
				System.out.println("Invalid Mobile Number");
			}
	}
}
