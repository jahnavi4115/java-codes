package com.school;

import java.util.Scanner;

import org.hibernate.HibernateException;

import com.school.dao.StudentDAOImpl;

public class RegisterStudentData {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id : ");
		int id=Integer.parseInt(sc.nextLine());
		System.out.println("Enter name : ");
		String name=sc.nextLine();
		System.out.println("Enter marks : ");
		int marks=Integer.parseInt(sc.nextLine());
		System.out.println("Enter email : ");
		String email=sc.nextLine();
		System.out.println("Enter mobile number : ");
		long number=Long.parseLong(sc.nextLine());
		try{
			StudentDAOImpl studentDAO=new StudentDAOImpl();
			StudentVo student=new StudentVo();
			student.setId(id);
			student.setName(name);
			student.setMarks(marks);
			student.setEmailId(email);
			student.setMobileNumber(number);
			int result=studentDAO.addStudent(student);
			if(result>0)
			{
				System.out.println("Inserted Successfully");
			}
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
		sc.close();
	}
}
