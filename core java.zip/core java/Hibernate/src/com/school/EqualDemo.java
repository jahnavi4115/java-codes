package com.school;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.school.util.DbUtil;

public class EqualDemo {
	public static void main(String[] args) {
		try
		{
			DbUtil dbUtil=new DbUtil();
			Session session=dbUtil.getMySession();
			Criteria criteria=session.createCriteria(StudentVo.class);
			criteria.add(Restrictions.eq("name","Dakshayani"));
			List<StudentVo> listOfStudents=criteria.list();
			Iterator iterator=listOfStudents.iterator();
			if(!listOfStudents.isEmpty())
			{
				System.out.println("Id  Name  Marks     Email       Mobile Number");
				System.out.println("--  ----  -----     -----       -------------");
				while(iterator.hasNext())
				{
					StudentVo student=(StudentVo) iterator.next();
					System.out.print(student.getId()+" ");
					System.out.print(student.getName()+" ");
					System.out.print(student.getMarks()+" ");
					System.out.print(student.getEmailId()+" ");
					System.out.println(student.getMobileNumber()+" ");
				}
			}
			else
			{
				System.out.println("Data not found");
			}
		}
		catch(HibernateException h)
		{
			System.out.println(h);
		}
	}
}
