package com.school;

import java.util.Scanner;

import com.school.dao.StudentDAOImpl;

public class UpdateStudentRecord {
	public static void main(String[] args) {
		StudentDAOImpl studentDAO=new StudentDAOImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id : ");
		int id=Integer.parseInt(sc.nextLine());
		StudentVo studentVo=new StudentVo();
		/*System.out.println("Enter name : ");
		String name=sc.nextLine();*/
		System.out.println("Enter marks : ");
		int marks=Integer.parseInt(sc.nextLine());
		System.out.println("Enter email : ");
		String email=sc.nextLine();
		System.out.println("Enter mobile number : ");
		long number=Long.parseLong(sc.nextLine());
		sc.close();
		studentVo.setId(id);
		//studentVo.setName(name);
		studentVo.setMarks(marks);
		studentVo.setEmailId(email);
		studentVo.setMobileNumber(number);
		boolean result=studentDAO.updateRecord(studentVo);
		if(result)
		{
			System.out.println("Updated Successfully");
		}
		else
		{
			System.out.println("Invalid Id");
		}
	}
}
